﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using Common;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.IO;
using System.Drawing.Imaging;

namespace Task
{
    public static class BL_Login
    {
        public static bool  AddNewUser(DataTable userDetails, byte[] imgByte)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_NAME", userDetails.Rows[0]["USER_NAME"].ToString()));
                lstInParam.Add(new SqlParameter("@P_PASSWORD", userDetails.Rows[0]["PASSWORD"].ToString()));
                lstInParam.Add(new SqlParameter("@P_EMAIL_ID", userDetails.Rows[0]["EMAIL_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_MOBILE_NO", userDetails.Rows[0]["MOBILE_NO"].ToLong()));
                lstInParam.Add(new SqlParameter("@P_PHOTO", imgByte));
                lstInParam.Add(new SqlParameter("@P_CREATED_BY", userDetails.Rows[0]["USER_ID"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CREATE_USER", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static bool ModifyUser(DataTable userDetails, Byte[] imgByte)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_ID", userDetails.Rows[0]["USER_ID"].ToLong()));
                lstInParam.Add(new SqlParameter("@P_USER_NAME", userDetails.Rows[0]["USER_NAME"].ToString()));
                lstInParam.Add(new SqlParameter("@P_PASSWORD", userDetails.Rows[0]["PASSWORD"].ToString()));
                lstInParam.Add(new SqlParameter("@P_EMAIL_ID", userDetails.Rows[0]["EMAIL_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_MOBILE_NO", userDetails.Rows[0]["MOBILE_NO"].ToLong()));
                lstInParam.Add(new SqlParameter("@P_PHOTO", imgByte));
                lstInParam.Add(new SqlParameter("@P_MODIFY_BY", userDetails.Rows[0]["USER_ID"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_UPDATE_USER", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static bool ChangePassword(long userId, string password)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_ID", userId));
                lstInParam.Add(new SqlParameter("@P_PASSWORD", password));
                lstInParam.Add(new SqlParameter("@P_MODIFY_BY", userId));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CHANGE_PASSWORD", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static DataTable CHECK_USER_IS_VALID(string  userName, string password)
        {
            DataTable dt;

            try
            {
                dt = (new DataAccess()).DB_Live.Get_Data_With_Inputs_Only("[SP_CHECK_USER_DETAILS]", new string[] { "@P_USER_NAME", "@P_PASSWORD" }, new string[] { userName, password });
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return  dt;
            
        }

        public static DataTable Get_User_Details(long  userId)
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_USER_DETAILS", new string[] { "@P_USER_ID" }, new string[] { userId.ToString() });
        }

        public static DataTable Get_User_Id(string userName)
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_USER_ID", new string[] { "@P_USER_NAME" }, new string[] { userName.ToString() });
        }

        public static bool Remove_User(long userId, long removeUserId)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_ID", userId));
                lstInParam.Add(new SqlParameter("@P_CANCEL_BY", removeUserId));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CANCEL_USER", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }
    }
}