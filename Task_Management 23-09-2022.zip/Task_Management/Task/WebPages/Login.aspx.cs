﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Common;
using System.Configuration;
//using System.Windows.Forms;
using System.Net;
using System.Web.Security;
using MessageLibrary;
using Error_Handler_Control;

namespace Task
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
             if(!IsPostBack)
            {
                txtUserName.Text = "";
                txtPassword.Text = "";
                txtUserName.Focus();
            }
        }

        protected void lbregister_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/WebPages/Registration.aspx");
        }

        protected void lbforgetpass_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/WebPages/ForgetPassword.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string strUserName = "", strPassword = "";
            bool blnUserIsValid = false;
            DataTable dtUserId;
            try
            {
                strUserName = txtUserName.Text.Trim();
                strPassword = txtPassword.Text.Trim();

                dtUserId = BL_Login.CHECK_USER_IS_VALID(strUserName, strPassword);

                if(dtUserId.Rows.Count>0)
                {
                    Session["Username"] = txtUserName.Text;
                    Session["Password"] = txtPassword.Text;
                    Session["USERID"] = dtUserId.Rows[0]["USER_ID_PK"].ToLong();

                    HttpCookie userInfo = new HttpCookie("userInfo");
                    userInfo["UserName"] = txtUserName.Text;
                    userInfo["Password"] = txtPassword.Text;
                    userInfo.Expires.Add(new TimeSpan(0, 10, 0));
                    Response.Cookies.Add(userInfo);

    
                    ErrorSuccessNotifier.AddSuccessMessage("Login Successfully");
                    //Response.Write("Login Successfully");
                   // Page.RegisterStartupScript("User Msg", "<script>alert('Login Successfully');</script>");
                   Response.Redirect("~/Default.aspx");
                }
                else
                {
                    ErrorSuccessNotifier.AddWarningMessage("Invalid Username or Password");
                    
                    //Server.TransferRequest(Request.Url.AbsolutePath, false);
                    txtUserName.Focus();
                }
            }
            catch (Exception ex)
            {
                ErrorSuccessNotifier.AddErrorMessage(ex.Message);
                //Server.TransferRequest(Request.Url.AbsolutePath, false);
                //txtUserName.Focus();
                //throw ex;
            }
        }
    }
}