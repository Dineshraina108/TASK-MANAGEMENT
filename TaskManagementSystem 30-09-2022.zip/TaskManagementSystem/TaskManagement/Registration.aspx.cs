﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TaskManagement
{
    public partial class Regsiteration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtRegUserName.Focus();
            }
        }

        protected void lbtnlogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Login.aspx");
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            DataTable dtUserData = new DataTable();
            string[] strParameters;
            string[] strValues;
            bool blResult = false;
            byte[] imgbyte = { };
            DataTable dtUserId;
            long lngUserId = 1;
            try
            {

                if (UserSession.UserID.GetStringValue() != "")
                    lngUserId = UserSession.UserID.ToLong();
                
                strParameters = new string[] { "USER_NAME", "PASSWORD", "EMAIL_ID", "MOBILE_NO", "USER_ID" };

                strValues = new string[] { txtRegUserName.Text.Trim(), txtRegPassword.Text.Trim(), txtEmail.Text.Trim(),
                                           txtmobileno.Text.Trim(), lngUserId.ToString()  };

                dtUserData = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                if (fuPhoto.HasFile)
                {
                    //getting length of uploaded file
                    int length = fuPhoto.PostedFile.ContentLength;
                    //create a byte array to store the binary image data
                    imgbyte = new byte[length];
                    //store the currently selected file in memeory
                    HttpPostedFile img = fuPhoto.PostedFile;
                    //set the binary data
                    img.InputStream.Read(imgbyte, 0, length);
                }

                if (dtUserData.HasRecords())
                {
                    blResult = BL_Login.AddNewUser(dtUserData, imgbyte);

                    if (blResult)
                    {
                        dtUserId = BL_Login.Get_User_Id(txtRegUserName.Text.Trim());
                        if (dtUserId.HasRecords())
                        {
                            Session["REG_USER_ID"] = dtUserId.Rows[0]["USER_ID_PK"].ToLong();
                        }

                        Response.Write("Register Successfully");
                        Response.Redirect("~/User_Profile.aspx", false);
                    }
                    else
                    {
                        Response.Write("Registration Failed");
                        Response.Redirect("~/Registreation.aspx", false);
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/Registeration.aspx", false);
            }
        }
    }
}