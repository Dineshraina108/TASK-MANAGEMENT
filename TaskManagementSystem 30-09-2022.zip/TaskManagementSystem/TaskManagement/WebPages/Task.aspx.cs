﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Common;

namespace TaskManagement.WebPages
{
    public partial class Task : System.Web.UI.Page
    {
        long lngTaskId;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if(UserSession.UserID == 0)
                {
                    Response.Redirect("~/Login.aspx");
                }
                else
                {
                    Get_Task_Details();
                    txtTaskCode.Focus();
                }
            }
        }

        protected void grdTaskDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdTaskDetails.PageIndex = e.NewPageIndex;
            this.Get_Task_Details();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DataTable dtTaskDetails;
            string[] strParameters;
            string[] strValues;
            bool blResult = false;

            try
            {
                if(btnSubmit.Text =="ADD")
                {
                    strParameters = new string[] { "TASK_CODE", "TASK_DESC", "DURATION", "USER_ID" };

                    strValues = new string[] { txtTaskCode.Text.Trim(), txtTaskDesc.Text.Trim(), txtDuration.Text.Trim(), UserSession.UserID.ToString() };

                    dtTaskDetails = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                    if (dtTaskDetails.HasRecords())
                    {
                        blResult = BL_Task.Create_Task(dtTaskDetails);

                        if (blResult)
                        {
                            Response.Write("Task added Successfully");
                            Get_Task_Details();
                            Response.Redirect("~/WebPages/Task.aspx");
                        }
                        else
                        {
                            Response.Write("Failed to add Task");
                            Response.Redirect("~/WebPages/Task.aspx");
                        }
                    }
                    else
                    {
                        Response.Write("Task add with out Details");
                        Response.Redirect("~/WebPages/Task.aspx");
                    }
                }
                else if(btnSubmit.Text == "UPDATE")
                {
                    strParameters = new string[] { "TASK_ID", "TASK_CODE", "TASK_DESC", "DURATION", "USER_ID" };

                    strValues = new string[] { lngTaskId.ToString(), txtTaskCode.Text.Trim(), txtTaskDesc.Text.Trim(), txtDuration.Text.Trim(), UserSession.UserID.ToString() };

                    dtTaskDetails = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                    if (dtTaskDetails.HasRecords())
                    {
                        blResult = BL_Task.Modify_Task(dtTaskDetails);

                        if (blResult)
                        {
                            Response.Write("Task updated Successfully");
                            Response.Redirect("~/WebPages/Task.aspx");
                        }
                        else
                        {
                            Response.Write("Failed to update Task");
                            Response.Redirect("~/WebPages/Task.aspx");
                        }
                    }
                    else
                    {
                        Response.Write("Task update with out Details");
                        Response.Redirect("~/WebPages/Task.aspx");
                    }
                }
                else if(btnSubmit.Text == "DELETE")
                {
                    blResult = BL_Task.Cancel_Task(lngTaskId, UserSession.UserID);

                    if(blResult)
                    {
                        Response.Write("Task Deleted Successfully");
                        Response.Redirect("~/WebPages/Task.aspx");
                    }
                    else
                    {
                        Response.Write("Failed to Delete Task");
                        Response.Redirect("~/WebPages/Task.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/Task.aspx");
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtTaskCode.Text = "";
            txtTaskDesc.Text = "";
            txtDuration.Text = "";

            Response.Write("~/Default.aspx");

        }

        //protected void imgbtnEdit_Click(object sender, EventArgs e)
        //{
        //    lngTaskId = 0;

        //    ImageButton imgbtnSelectedRow = sender as ImageButton;
        //    GridViewRow SelectedRow = (GridViewRow)imgbtnSelectedRow.NamingContainer;

        //    btnSubmit.Text = "UPDATE";

        //    lngTaskId = SelectedRow.Cells[0].Text.ToLong();
        //    txtTaskCode.Text = SelectedRow.Cells[1].Text.ToString();
        //    txtTaskDesc.Text = SelectedRow.Cells[2].Text;
        //    txtDuration.Text = SelectedRow.Cells[3].Text;

        //    txtTaskCode.Focus();
        //}

        //protected void imgbtnDelete_Click(object sender, EventArgs e)
        //{
        //    lngTaskId = 0;

        //    ImageButton imgbtnSelectedRow = sender as ImageButton;
        //    GridViewRow SelectedRow = (GridViewRow)imgbtnSelectedRow.NamingContainer;

        //    btnSubmit.Text = "DELETE";

        //    lngTaskId = SelectedRow.Cells[0].Text.ToLong();
        //    txtTaskCode.Text = SelectedRow.Cells[1].Text.ToString();
        //    txtTaskDesc.Text = SelectedRow.Cells[2].Text;
        //    txtDuration.Text = SelectedRow.Cells[3].Text;

        //    btnSubmit.Focus();
        //}

        private void Get_Task_Details()
        {
            DataTable dtTaskDetails = new DataTable();

            try
            {
                dtTaskDetails = BL_Task.Get_Task_Details();

                if (dtTaskDetails.HasRecords())
                {
                    grdTaskDetails.DataSource = dtTaskDetails;
                    grdTaskDetails.DataBind();
                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/Task.aspx");
            }
        }
    }
}