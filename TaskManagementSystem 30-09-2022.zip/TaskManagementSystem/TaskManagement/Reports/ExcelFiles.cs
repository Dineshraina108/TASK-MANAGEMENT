﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common;
using System.Data;
using System.Drawing;
using Microsoft.Office.Interop;

namespace TaskManagement
{
    public static class ExcelFiles
    {

        public static void Get_Contact_Details(DataTable contactDetails)
        {

            int CurrentRow = 1, SNo=1;
            Microsoft.Office.Interop.Excel.Range formatRange;

            Microsoft.Office.Interop.Excel.Application APPL;
            Microsoft.Office.Interop.Excel.Workbook workbook = null;
            Microsoft.Office.Interop.Excel.Worksheet WSheet = new Microsoft.Office.Interop.Excel.Worksheet();

            APPL = new Microsoft.Office.Interop.Excel.Application();
            workbook = APPL.Workbooks.Add();
            WSheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;
            WSheet.Name = "CONTACT DATA";
            WSheet.Cells.Font.Name = "Calibri";
            WSheet.Cells.Font.Size = 10;

            try
            {

                string filepath = @"D:\Anguler\Project\TaskManagementSystem\TaskManagement\ContactDetails\ContactDetails" + DateTime.Now.Date.ToShortDateString() + ".xlsx";

                if (System.IO.File.Exists(filepath))
                {

                    workbook = APPL.Workbooks.Open(filepath, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false); //Open(filepath,ReadOnly:false);
                    string ExcelWorkbookname = workbook.Name;
                    int worksheetcount = workbook.Worksheets.Count;
                    WSheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];

                    Microsoft.Office.Interop.Excel.Range last = WSheet.Cells.SpecialCells(Microsoft.Office.Interop.Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                    Microsoft.Office.Interop.Excel.Range range = WSheet.get_Range("A1", last);

                    CurrentRow = last.Row;
                    //int lastUsedColumn = last.Column;
                    CurrentRow = CurrentRow + 1;
                    SNo = CurrentRow;
                    WSheet.Cells[CurrentRow, 1] = SNo;
                    WSheet.Cells[CurrentRow, 2] = DateTime.Now.Date.ToShortDateString();
                    WSheet.Cells[CurrentRow, 3] = contactDetails.Rows[0]["NAME"].GetStringValue();
                    WSheet.Cells[CurrentRow, 4] = contactDetails.Rows[0]["MOBILE_NO"].GetStringValue();
                    WSheet.Cells[CurrentRow, 5] = contactDetails.Rows[0]["EMAIL_ID"].GetStringValue();
                    WSheet.Cells[CurrentRow, 6] = contactDetails.Rows[0]["MESSAGE"].GetStringValue();
                    WSheet.Range["F" + CurrentRow].WrapText = true;

                    WSheet.Range[WSheet.Cells[1, 1], WSheet.Cells[CurrentRow, 6]].Cells.Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;

                    CurrentRow = CurrentRow + 2;

                    workbook.Save();
                }
                else
                {
                    CurrentRow = CurrentRow + 1;

                    WSheet.Cells[CurrentRow, 1] = "CONTACT DETAILS";
                    WSheet.Range["A" + CurrentRow, "F" + CurrentRow].Font.Bold = true;
                    WSheet.Range["A" + CurrentRow, "F" + CurrentRow].Merge();
                    WSheet.Range["A" + CurrentRow, "F" + CurrentRow].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    formatRange = WSheet.Range["A" + CurrentRow, "F" + CurrentRow];
                    formatRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkMagenta);
                    formatRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightCyan);

                    CurrentRow = CurrentRow + 1;

                    WSheet.Cells[CurrentRow, 1] = "S.NO";
                    WSheet.Range["A" + CurrentRow].ColumnWidth = 15;
                    WSheet.Cells[CurrentRow, 2] = "DATE";
                    WSheet.Range["B" + CurrentRow].ColumnWidth = 20;
                    WSheet.Cells[CurrentRow, 3] = "NAME";
                    WSheet.Range["C" + CurrentRow].ColumnWidth = 20;
                    WSheet.Cells[CurrentRow, 4] = "MOBILE NO";
                    WSheet.Range["D" + CurrentRow].ColumnWidth = 20;
                    WSheet.Cells[CurrentRow, 5] = "EMAIL ID";
                    WSheet.Range["E" + CurrentRow].ColumnWidth = 20;
                    WSheet.Cells[CurrentRow, 6] = "MESSAGE";
                    WSheet.Range["F" + CurrentRow].ColumnWidth = 40;
                    WSheet.Range["F" + CurrentRow].WrapText = true;

                    formatRange = WSheet.Range["A" + CurrentRow, "F" + CurrentRow];
                    formatRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Blue);
                    WSheet.Range["A" + CurrentRow, "F" + CurrentRow].Font.Bold = true;

                    CurrentRow = CurrentRow + 1;

                    WSheet.Cells[CurrentRow, 1] = SNo;
                    WSheet.Cells[CurrentRow, 2] = DateTime.Now.Date.ToShortDateString();
                    WSheet.Cells[CurrentRow, 3] = contactDetails.Rows[0]["NAME"].GetStringValue();
                    WSheet.Cells[CurrentRow, 4] = contactDetails.Rows[0]["MOBILE_NO"].GetStringValue();
                    WSheet.Cells[CurrentRow, 5] = contactDetails.Rows[0]["EMAIL_ID"].GetStringValue();
                    WSheet.Cells[CurrentRow, 6] = contactDetails.Rows[0]["MESSAGE"].GetStringValue();
                    WSheet.Range["F" + CurrentRow].WrapText = true;

                    WSheet.Range[WSheet.Cells[1, 1], WSheet.Cells[CurrentRow, 6]].Cells.Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;

                    CurrentRow = CurrentRow + 1;

                    object missing = System.Reflection.Missing.Value;


                    workbook.SaveAs(filepath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, missing, missing,
                                        false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                                        missing, missing, missing, missing, missing);

                }

                //  workbook.Application.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}