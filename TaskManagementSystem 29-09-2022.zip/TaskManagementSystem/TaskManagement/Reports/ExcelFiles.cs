﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common;
using System.Data;
using System.Drawing;
using Microsoft.Office.Interop;

namespace TaskManagement
{
    public static class ExcelFiles
    {

        public static void Get_Contact_Details(DataTable contactDetails)
        {

            int CurrentRow = 1;
            Microsoft.Office.Interop.Excel.Range formatRange;

            Microsoft.Office.Interop.Excel.Application APPL;
            Microsoft.Office.Interop.Excel.Workbook workbook = null;
            Microsoft.Office.Interop.Excel.Worksheet WSheet = new Microsoft.Office.Interop.Excel.Worksheet();

            APPL = new Microsoft.Office.Interop.Excel.Application();
            workbook = APPL.Workbooks.Add();
            WSheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;
            WSheet.Name = "CONTACT DATA";
            WSheet.Cells.Font.Name = "Calibri";
            WSheet.Cells.Font.Size = 10;

            try
            {

                CurrentRow = CurrentRow + 1;

                WSheet.Cells[CurrentRow, 1] = "CONTACT DETAILS";
                WSheet.Range["A" + CurrentRow, "E" + CurrentRow].Font.Bold = true;
                WSheet.Range["A" + CurrentRow, "E" + CurrentRow].Merge();
                WSheet.Range["A" + CurrentRow, "E" + CurrentRow].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                formatRange = WSheet.Range["A" + CurrentRow, "E" + CurrentRow];
                formatRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkMagenta);
                formatRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightCyan);

                CurrentRow = CurrentRow + 1;

                WSheet.Cells[CurrentRow, 1] = "DATE";
                WSheet.Range["A" + CurrentRow].ColumnWidth = 20;
                WSheet.Cells[CurrentRow, 2] = "NAME";
                WSheet.Range["B" + CurrentRow].ColumnWidth = 20;
                WSheet.Cells[CurrentRow, 3] = "MOBILE NO";
                WSheet.Range["C" + CurrentRow].ColumnWidth = 20;
                WSheet.Cells[CurrentRow, 4] = "EMAIL ID";
                WSheet.Range["D" + CurrentRow].ColumnWidth = 20;
                WSheet.Cells[CurrentRow, 5] = "MESSAGE";
                WSheet.Range["E" + CurrentRow].ColumnWidth = 40;
                WSheet.Range["E" + CurrentRow].WrapText = true;

                formatRange = WSheet.Range["A" + CurrentRow, "E" + CurrentRow];
                formatRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Blue);
                WSheet.Range["A" + CurrentRow, "E" + CurrentRow].Font.Bold = true;

                CurrentRow = CurrentRow + 1;

                WSheet.Cells[CurrentRow, 1] = DateTime.Now.Date.ToShortDateString();
                WSheet.Cells[CurrentRow, 2] = contactDetails.Rows[0]["NAME"].GetStringValue();
                WSheet.Cells[CurrentRow, 3] = contactDetails.Rows[0]["MOBILE_NO"].GetStringValue();
                WSheet.Cells[CurrentRow, 4] = contactDetails.Rows[0]["EMAIL_ID"].GetStringValue();
                WSheet.Cells[CurrentRow, 5] = contactDetails.Rows[0]["MESSAGE"].GetStringValue();
                WSheet.Range["E" + CurrentRow].WrapText = true;

                WSheet.Range[WSheet.Cells[1, 1], WSheet.Cells[CurrentRow, 5]].Cells.Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;

                CurrentRow = CurrentRow + 2;

                workbook.Application.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}