﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Common;

namespace TaskManagement
{
    /// <summary>
    /// Summary description for ImageHandler
    /// </summary>
    public class ImageHandler : IHttpHandler
    {

        DataTable dtImage;

        public void ProcessRequest(HttpContext context)
        {
            //context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");

            string imageid = context.Request.QueryString["ImID"];

            dtImage = BL_Login.Get_User_photo(imageid.ToLong());

            if(dtImage.HasRecords())
            {
                context.Response.BinaryWrite((Byte[])dtImage.Rows[0]["PHOTO"]);
            }
           
            context.Response.End();

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}