﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TaskManagement
{
    public class BL_Task
    {
        public static bool Create_Task(DataTable taskDetails)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_TASK_CODE", taskDetails.Rows[0]["TASK_CODE"].ToString()));
                lstInParam.Add(new SqlParameter("@P_TASK_DESC", taskDetails.Rows[0]["TASK_DESC"].ToString()));
                lstInParam.Add(new SqlParameter("@P_DURATION", taskDetails.Rows[0]["DURATION"].ToString()));
                lstInParam.Add(new SqlParameter("@P_CREATED_BY", taskDetails.Rows[0]["USER_ID"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CREATE_TASK", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static bool Modify_Task(DataTable taskDetails)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_TASK_ID", taskDetails.Rows[0]["TASK_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_TASK_CODE", taskDetails.Rows[0]["TASK_CODE"].ToString()));
                lstInParam.Add(new SqlParameter("@P_TASK_DESC", taskDetails.Rows[0]["TASK_DESC"].ToString()));
                lstInParam.Add(new SqlParameter("@P_DURATION", taskDetails.Rows[0]["DURATION"].ToString()));
                lstInParam.Add(new SqlParameter("@P_MODIFY_BY", taskDetails.Rows[0]["MODIFY_BY"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_MODIFY_TASK", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static bool Cancel_Task(long TaskId, long userId)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_TASK_ID", TaskId));
                lstInParam.Add(new SqlParameter("@P_CANCEL_BY", userId));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CANCEL_TASK", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static DataTable Get_Task_Details()
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_TASK_DETAILS", null, null);
        }

        public static DataTable Get_Task_Details(string duration)
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_TASKS", new string[] { "@P_DURATION" }, new string[] { duration });
        }

        public static DataTable Get_Duration()
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_DURATIONS", null, null);
        }

    }
}