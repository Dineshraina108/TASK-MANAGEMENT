﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TaskManagement;

namespace TaskManagement
{
    public partial class Login : System.Web.UI.Page
    {
        string strUserName, strPassword;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtUserName.Text = "";
                txtPassword.Text = "";
                txtUserName.Focus();
            }
        }

        protected void lbregister_Click(object sender, EventArgs e)
        {

        }

        protected void lbforgetpass_Click(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            DataTable dtUserId;
            try
            {
                strUserName = txtUserName.Text.Trim();
                strPassword = txtPassword.Text.Trim();

                dtUserId = BL_Login.CHECK_USER_IS_VALID(strUserName, strPassword);

                if (dtUserId.Rows.Count > 0)
                {
                    Session["Username"] = txtUserName.Text;
                    Session["Password"] = txtPassword.Text;
                    Session["USERID"] = dtUserId.Rows[0]["USER_ID_PK"].ToLong();

                    UserSession.UserID= dtUserId.Rows[0]["USER_ID_PK"].ToLong();
                    UserSession.UserName = txtUserName.Text.Trim();
                    UserSession.Password = txtPassword.Text.Trim();

                    //HttpCookie userInfo = new HttpCookie("userInfo");
                    //userInfo["UserName"] = txtUserName.Text;
                    //userInfo["Password"] = txtPassword.Text;
                    //userInfo.Expires.Add(new TimeSpan(0, 10, 0));
                    //Response.Cookies.Add(userInfo)
                    Response.Write("<script> alert('Login Successfully')</script>");
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    Response.Redirect("~/Login.aspx");
                    txtUserName.Focus();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}