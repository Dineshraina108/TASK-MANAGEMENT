﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using Common;

namespace TaskManagement
{
    public class DataAccess
    {
        public DataHelper DB_Live = new DataHelper("Data Source=DESKTOP-32D44P8\\SQLEXPRESS;Initial Catalog=DB_TASK_MANANGEMENT;Integrated Security=True");
    }
}