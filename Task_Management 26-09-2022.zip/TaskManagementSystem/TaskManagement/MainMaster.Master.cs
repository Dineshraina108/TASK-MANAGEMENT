﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TaskManagement
{
    public partial class MainMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                if (UserSession.UserName.GetStringValue() != "")
                    LoginUserName.Text = "Welcome   " + UserSession.UserName.PascalCase();
           
        }

        protected void lbtnLogout_Click(object sender, EventArgs e)
        {
            Session["Username"] = null;
            Session["Password"] = null;
            Session["USERID"] = null;

            UserSession.UserID = 0;
            UserSession.UserName = null;
            UserSession.Password = null;

            Response.Redirect("/Login.aspx");
        }
    }
}