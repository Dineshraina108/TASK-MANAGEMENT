﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using System.Data;

namespace TaskManagement
{
    public partial class UserDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
                Get_Details();
            //}
        }

        protected void grdUserDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }

        protected void grdUserDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

        }

        protected void grdUserDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {


        }

        protected void grdUserDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {


        }

        protected void grdUserDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        private void Get_Details()
        {
            DataTable dtUserDetails;

            try
            {
                dtUserDetails = BL_Login.Get_User_Details();

                if(dtUserDetails.HasRecords())
                {
                    lblresult.Text = "";
                    grdUserDetails.DataSource = dtUserDetails;
                    }
                else
                {
                    lblresult.Text = "No Users are available ";
                }
            }
            catch (Exception ex)
            {

                throw ex ;
            }
        }

        protected void grdUserDetails_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        protected void imgbtnEdit_Click(object sender, EventArgs e)
        {
            ImageButton imgbtn = sender as ImageButton;
            //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ShowValidation", "javascript:ShowImages();", true);
        }



        protected void imgbtnDelete_Click(object sender, EventArgs e)
        {
            ImageButton imgbtn = sender as ImageButton;
            //ScriptManager.RegisterStartupScript(Page, typeof(Page), "ShowValidation", "javascript:ShowImages();", true);
        }
    }
}