﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TaskManagement
{
    public static class UserSession
    {
        public static long UserID;

        public static string UserName;

        public static string Password;
    }
}