﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Common;
using System.IO;
using System.Drawing.Imaging;

namespace Task.WebPages
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {

            }
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            DataTable dtUserData = new DataTable();
            string[] strParameters;
            string[] strValues;
            bool blResult = false;
            byte[] imgbyte= { };
            DataTable dtUserId;

            try
            {
                strParameters = new string[] { "USER_NAME", "PASSWORD", "EMAIL_ID", "MOBILE_NO", "USER_ID" };

                strValues = new string[] { txtRegUserName.Text.Trim(), txtRegPassword.Text.Trim(), txtEmail.Text.Trim(),
                                           txtmobileno.Text.Trim(), Session["USERID"].ToString() };

                dtUserData = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                if (fuPhoto.HasFile)
                {
                    //getting length of uploaded file
                    int length = fuPhoto.PostedFile.ContentLength;
                    //create a byte array to store the binary image data
                    imgbyte = new byte[length];
                    //store the currently selected file in memeory
                    HttpPostedFile img = fuPhoto.PostedFile;
                    //set the binary data
                    img.InputStream.Read(imgbyte, 0, length);
                } 
                
                if(dtUserData.HasRecords())
                {
                    blResult = BL_Login.AddNewUser(dtUserData, imgbyte);

                    if (blResult)
                    {
                        Response.Write("Register Successfully");

                        dtUserId = BL_Login.Get_User_Id(txtRegUserName.Text.Trim());
                        if(dtUserId.HasRecords())
                        {
                            Session["REG_USER_ID"] = dtUserId.Rows[0]["USER_ID_PK"].ToLong();
                        }

                        Response.Redirect("~/WebPages/User_Profile.aspx");
                    }
                    else
                    {
                        Response.Write("Reguistration Failed");
                        Response.Redirect("~/WebPages/Registration.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/Registration.aspx");
            }
            
        }

        protected void lbtnlogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/WebPages/Login.aspx");
        }
    }
}