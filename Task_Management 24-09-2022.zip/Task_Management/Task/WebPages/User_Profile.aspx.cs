﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;

namespace Task.WebPages
{
    public partial class User_Profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {

            }
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            DataTable dtUserData = new DataTable();
            string[] strParameters;
            string[] strValues;
            bool blResult = false;
            string strGender = "";


            try
            {
                if (RbMale.Checked)
                    strGender = RbMale.Text;
                else
                    strGender = RbFemale.Text;

                strParameters = new string[] { "USER_ID", "CAREER_ID", "NAME", "DOB", "GENDER", "JOB_POSTION" , "CREATE_BY" };

                strValues = new string[] { Session["REG_USER_ID"].ToString(), txtcareerId.Text.Trim(), txtName.Text.Trim(),
                                           txtDOB.Text.Trim(), strGender, txtJobPosition.Text.Trim(), Session["USERID"].ToString() };

                dtUserData = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                if (dtUserData.HasRecords())
                {
                    blResult = BL_USER_PROFILE.Create_User_profile(dtUserData);

                    if (blResult)
                    {
                        Response.Write("Profile added Successfully");
                        Response.Redirect("~/Default.aspx");
                    }
                    else
                    {
                        Response.Write("Profile Failed to Add");
                        Response.Redirect("~/WebPages/User_Profile.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/User_Profile.aspx");
            }
        }
    }
}