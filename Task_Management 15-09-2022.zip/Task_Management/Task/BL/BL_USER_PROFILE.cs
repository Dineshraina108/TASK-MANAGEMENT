﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using Common;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.IO;
using System.Drawing.Imaging;

namespace Task.BL
{
    public static class BL_USER_PROFILE
    {
        public static bool Create_User_profile(DataTable userProfile)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_ID", userProfile.Rows[0]["USER_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_CAREER_ID", userProfile.Rows[0]["CAREER_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_NAME", userProfile.Rows[0]["NAME"].ToString()));
                lstInParam.Add(new SqlParameter("@P_DOB", userProfile.Rows[0]["DOB"].ToString()));
                lstInParam.Add(new SqlParameter("@P_GENDER", userProfile.Rows[0]["GENDER"].ToString()));
                lstInParam.Add(new SqlParameter("@P_JOB_POSTION", userProfile.Rows[0]["JOB_POSTION"].ToString()));
                lstInParam.Add(new SqlParameter("@P_CREATED_BY", userProfile.Rows[0]["USER_ID"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CREATE_USER_PROFILE", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static bool Modify_User_profile(DataTable profileDetails)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_ID", profileDetails.Rows[0]["USER_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_NAME", profileDetails.Rows[0]["NAME"].ToString()));
                lstInParam.Add(new SqlParameter("@P_DOB", profileDetails.Rows[0]["DOB"].ToString()));
                lstInParam.Add(new SqlParameter("@P_GENDER", profileDetails.Rows[0]["GENDER"].ToString()));
                lstInParam.Add(new SqlParameter("@P_JOB_POSTION", profileDetails.Rows[0]["JOB_POSTION"].ToString()));
                lstInParam.Add(new SqlParameter("@P_MODIFY_BY", profileDetails.Rows[0]["USER_ID"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_MODIFY_USER_PROFILE", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static DataTable Get_User_profile_Details(long userId)
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_USER_PROFILE", new string[] { "@P_USER_ID" }, new string[] { userId.ToString() });
        }

        public static bool Remove_User_profile(long userId, long removeUserId)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_ID", userId));
                lstInParam.Add(new SqlParameter("@P_DELETE_BY", removeUserId));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_DELETE_USER_PROFILE", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }
    }
}