﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class DBConnectionException : Exception
    {
        public DBConnectionException(string Message) : base(Message)
        {

        }

        public DBConnectionException(string Message, Exception ex) : base(Message, ex)
        {

        }
    }

    public class ValueTooLargeException : Exception
    {
        public ValueTooLargeException(string Message) : base(Message)
        {

        }

        public ValueTooLargeException(string Message, Exception ex) : base(Message, ex)
        {

        }
    }

    public class MissingDataException : Exception
    {
        public MissingDataException(string Message) : base(Message)
        {

        }

        public MissingDataException(string Message, Exception ex) : base(Message, ex)
        {

        }
    }
}
