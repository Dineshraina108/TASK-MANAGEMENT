﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
namespace MessageLibrary
{
    public static class MyMessage
    {
        static Button OK     = new Button();
        static Button CANCEL = new Button();
        static Button YES    = new Button();
        static Button NO     = new Button();
        static Button RETRY  = new Button();
        static Button ABORT  = new Button();
        static Button IGNORE = new Button();

        static MessageForm MF;
        static int btnWith = 80;
        static Color btnColor = Color.Transparent;

        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MessageForm());
        }

        public static DialogResult ShowMessage(string Message, MessageBoxButtons MBB = MessageBoxButtons.OK, MessageType MT = MessageType.Information)
        {
            MF = new MessageForm();
            CustomizeButtons();
            AddButton(MBB, MT);
            AddIcon(MT);
            MF.lblMessage.Text = Message;
            MF.ShowDialog();
            return MF.DialogResult;
        }

        private static void CustomizeButtons()
        {
            OK.Width = btnWith;
            OK.Text = "OK";
            OK.BackColor = btnColor;
            OK.Click += new EventHandler(buttonOK_click);
            CANCEL.Width = btnWith;
            CANCEL.Text = "Cancel";
            CANCEL.BackColor = btnColor;
            CANCEL.Click += new EventHandler(buttonCancel_click);
            YES.Width = btnWith;
            YES.Text = "Yes";
            YES.BackColor = btnColor;
            YES.Click += new EventHandler(buttonYes_click);
            NO.Width = btnWith;
            NO.Text = "No";
            NO.BackColor = btnColor;
            NO.Click += new EventHandler(buttonNo_click);
            RETRY.Width = btnWith;
            RETRY.Text = "Retry";
            RETRY.BackColor = btnColor;
            RETRY.Click += new EventHandler(buttonRetry_click);
            ABORT.Width = btnWith;
            ABORT.Text = "Abort";
            ABORT.BackColor = btnColor;
            ABORT.Click += new EventHandler(buttonAbort_click);
            IGNORE.Width = btnWith;
            IGNORE.Text = "Ignore";
            IGNORE.BackColor = btnColor;
            IGNORE.Click += new EventHandler(buttonIgnore_click);
        }

        private static void AddButton(MessageBoxButtons MBB, MessageType MT)
        {
            if (MBB == MessageBoxButtons.OK)
            {
                OK.Location = new Point(400, 140);
                MF.Controls.Add(OK);
                SetButtonStyles(OK);
                SetButtonColor(OK, MT);
            }
            else if (MBB == MessageBoxButtons.OKCancel)
            {
                OK.Location = new Point(300, 140);
                CANCEL.Location = new Point(400, 140);
                MF.Controls.Add(OK);
                MF.Controls.Add(CANCEL);

                SetButtonStyles(OK);
                SetButtonStyles(CANCEL);

                SetButtonColor(OK, MT);
                SetButtonColor(CANCEL, MT);
            }
            else if (MBB == MessageBoxButtons.YesNo)
            {
                YES.Location = new Point(300, 140);
                NO.Location = new Point(400, 140);
                MF.Controls.Add(YES);
                MF.Controls.Add(NO);

                SetButtonStyles(YES);
                SetButtonStyles(NO);

                SetButtonColor(YES, MT);
                SetButtonColor(NO, MT);
            }
            else if (MBB == MessageBoxButtons.YesNoCancel)
            {
                YES.Location = new Point(200, 140);
                NO.Location = new Point(300, 140);
                CANCEL.Location = new Point(400, 140);
                MF.Controls.Add(YES);
                MF.Controls.Add(NO);
                MF.Controls.Add(CANCEL);

                SetButtonStyles(YES);
                SetButtonStyles(NO);
                SetButtonStyles(CANCEL);

                SetButtonColor(YES, MT);
                SetButtonColor(NO, MT);
                SetButtonColor(CANCEL, MT);
            }
            else if (MBB == MessageBoxButtons.RetryCancel)
            {
                RETRY.Location = new Point(300, 140);
                CANCEL.Location = new Point(400, 140);
                MF.Controls.Add(RETRY);
                MF.Controls.Add(CANCEL);

                SetButtonStyles(RETRY);
                SetButtonStyles(CANCEL);

                SetButtonColor(RETRY, MT);
                SetButtonColor(CANCEL, MT);
            }
            else if (MBB == MessageBoxButtons.AbortRetryIgnore)
            {
                ABORT.Location = new Point(200, 140);
                RETRY.Location = new Point(300, 140);
                IGNORE.Location = new Point(400, 140);
                MF.Controls.Add(RETRY);
                MF.Controls.Add(IGNORE);

                SetButtonStyles(ABORT);
                SetButtonStyles(RETRY);
                SetButtonStyles(IGNORE);

                SetButtonColor(ABORT, MT);
                SetButtonColor(RETRY, MT);
                SetButtonColor(IGNORE, MT);
            }
        }

        private static void buttonOK_click(object sender, EventArgs e)
        {
            MF.DialogResult = DialogResult.OK;
            MF.Close();
        }

        private static void buttonCancel_click(object sender, EventArgs e)
        {
            MF.DialogResult = DialogResult.Cancel;
            MF.Close();
        }

        private static void buttonYes_click(object sender, EventArgs e)
        {
            MF.DialogResult = DialogResult.Yes;
            MF.Close();
        }

        private static void buttonNo_click(object sender, EventArgs e)
        {
            MF.DialogResult = DialogResult.No;
            MF.Close();
        }

        private static void buttonRetry_click(object sender, EventArgs e)
        {
            MF.DialogResult = DialogResult.Retry;
            MF.Close();
        }

        private static void buttonAbort_click(object sender, EventArgs e)
        {
            MF.DialogResult = DialogResult.Abort;
            MF.Close();
        }

        private static void buttonIgnore_click(object sender, EventArgs e)
        {
            MF.DialogResult = DialogResult.Ignore;
            MF.Close();
        }

        private static void AddIcon(MessageType MT)
        {
            if (MT == MessageType.Success)
            {
                MF.Text = Convert.ToString(MessageType.Success);
                MF.BackColor = Color.DarkSeaGreen;
                MF.MessageIcon.Image = Properties.Resources.Success;
            }
            else if (MT == MessageType.Failed)
            {
                MF.Text = Convert.ToString(MessageType.Failed);
                MF.BackColor = Color.LightSalmon;
                MF.MessageIcon.Image = Properties.Resources.Failed;
            }
            else if (MT == MessageType.Error)
            {
                MF.Text = Convert.ToString(MessageType.Error);
                MF.BackColor = Color.LightSalmon;
                MF.MessageIcon.Image = Properties.Resources.Error;
            }
            else if (MT == MessageType.Exception)
            {
                MF.Text = Convert.ToString(MessageType.Exception);
                MF.BackColor = Color.Orange;
                MF.MessageIcon.Image = Properties.Resources.Exception;
            }
            else if (MT == MessageType.Warning)
            {
                MF.Text = Convert.ToString(MessageType.Warning);
                MF.BackColor = Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(0)))));
                MF.MessageIcon.Image = Properties.Resources.Warning;
            }
            else if (MT == MessageType.Question)
            {
                MF.Text = Convert.ToString(MessageType.Question);
                MF.BackColor = Color.LightBlue;
                MF.MessageIcon.Image = Properties.Resources.Question;
            }
            else
            {
                MF.Text = Convert.ToString(MessageType.Information);
                MF.BackColor = Color.PaleTurquoise;
                MF.MessageIcon.Image = Properties.Resources.Information;
            }
        }

        private static void SetButtonColor(Button btn, MessageType MT)
        {
            btn.BackColor = Color.White;
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            if (MT == MessageType.Success)
            {
                btn.ForeColor = Color.DarkSeaGreen;
            }
            else if (MT == MessageType.Failed)
            {
                btn.ForeColor = Color.LightSalmon;
            }
            else if (MT == MessageType.Error)
            {
                btn.ForeColor = Color.LightSalmon;
            }
            else if (MT == MessageType.Exception)
            {
                btn.ForeColor = Color.Orange;
            }
            else if (MT == MessageType.Warning)
            {
                btn.ForeColor = Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(0)))));
            }
            else if (MT == MessageType.Question)
            {
                btn.ForeColor = Color.LightBlue;
            }
            else
            {
                btn.ForeColor = Color.PaleTurquoise;
            }
        }

        private static void SetButtonStyles(Button btn)
        {
            btn.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom
                | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right));
            btn.TextAlign = ContentAlignment.MiddleCenter;
        }

        public enum MessageType
        {
            Success,
            Failed,
            Error,
            Exception,
            Warning,
            Information,
            Question
        }

    }
}
