﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TaskManagement;

namespace TaskManagement
{
    public partial class Login : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtUserName.Text = "";
                txtPassword.Text = "";
                txtUserName.Focus();
            }
        }

        protected void lbregister_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Registration.aspx");
        }

        protected void lbforgetpass_Click(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string strUserName, strPassword;
            DataTable dtUserId;

            try
            {
                strUserName = txtUserName.Text.Trim();
                strPassword = txtPassword.Text.Trim();

                dtUserId = BL_Login.CHECK_USER_IS_VALID(strUserName, strPassword);

                if (dtUserId.Rows.Count > 0)
                {
                    Session["Username"] = txtUserName.Text;
                    Session["Password"] = txtPassword.Text;
                    Session["USERID"] = dtUserId.Rows[0]["USER_ID_PK"].ToLong();

                    UserSession.UserID= dtUserId.Rows[0]["USER_ID_PK"].ToLong();
                    UserSession.UserName = txtUserName.Text.Trim();
                    UserSession.Password = txtPassword.Text.Trim();

                    Console.WriteLine("Login Successfully");
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    Console.WriteLine("Login Failed");
                    Response.Redirect("~/Login.aspx");
                    txtUserName.Focus();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception", ex.Message);
                Response.Redirect("~/Login.aspx");
            }
        }
    }
}