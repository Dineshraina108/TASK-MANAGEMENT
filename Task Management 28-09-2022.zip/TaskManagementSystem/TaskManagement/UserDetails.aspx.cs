﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using System.Data;
using System.IO;
using System.Configuration;
using System.Drawing;

namespace TaskManagement
{
    public partial class UserDetails : System.Web.UI.Page
    {
        long lngUserId, lngBioId;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if(UserSession.UserID != 0)
                {
                    Get_Details();
                }
                else
                {
                    Response.Redirect("~/Login.aspx");
                }
               
            }
        }

      
        private void Get_Details()
        {
            DataTable dtUserDetails;

            try
            {
                dtUserDetails = BL_Login.Get_User_Details();

                if(dtUserDetails.HasRecords())
                {
                    lblresult.Text = "";
                    grdUserDetails.DataSource = dtUserDetails;
                    grdUserDetails.DataBind();
                }
                else
                {
                    lblresult.Text = "No Users are available ";
                }
            }
            catch (Exception ex)
            {

                throw ex ;
            }
        }

        protected void imgbtnEdit_Click(object sender, EventArgs e)
        {
            lngUserId = 0;
            lngBioId = 0;

            ImageButton imgbtnSelectedRow = sender as ImageButton;
            GridViewRow SelectedRow = (GridViewRow)imgbtnSelectedRow.NamingContainer;

            lngUserId = SelectedRow.Cells[0].Text.ToLong();
            lngBioId = SelectedRow.Cells[1].Text.ToLong();
            lblName.Text = SelectedRow.Cells[3].Text;
            txtDOB.Text = SelectedRow.Cells[4].Text;
            txtMobileNo.Text = SelectedRow.Cells[5].Text;
            txtEmailId.Text = SelectedRow.Cells[6].Text;
            txtJobPosition.Text = SelectedRow.Cells[7].Text;

            this.ModalPopupExtender1.Show();
        }



        protected void imgbtnDelete_Click(object sender, EventArgs e)
        {
            lngUserId = 0;
            lngBioId = 0;

            ImageButton imgbtnSelectedRow = sender as ImageButton;
            GridViewRow SelectedRow = (GridViewRow)imgbtnSelectedRow.NamingContainer;

            lngUserId = SelectedRow.Cells[0].Text.ToLong();
            lngBioId = SelectedRow.Cells[1].Text.ToLong();
            lblName.Text = SelectedRow.Cells[3].Text;
            txtDOB.Text = SelectedRow.Cells[4].Text;
            txtMobileNo.Text = SelectedRow.Cells[5].Text;
            txtEmailId.Text = SelectedRow.Cells[6].Text;
            txtJobPosition.Text = SelectedRow.Cells[7].Text;

            btnUpdate.Text = "DELETE";

            this.ModalPopupExtender1.Show();

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            DataTable dtUserData = new DataTable(), dtUserProfile = new DataTable();
            string[] strParameters;
            string[] strValues;
            bool blResult = false;
            //byte[] imgbyte = { };

            try
            {
                if (btnUpdate.Text == "UPFATE")
                {
                    if (UserSession.UserID.GetStringValue() != "")
                        lngUserId = UserSession.UserID.ToLong();

                    strParameters = new string[] { "USER_ID", "EMAIL_ID", "MOBILE_NO" };

                    strValues = new string[] { lngUserId.ToString(), txtEmailId.Text.Trim(), txtMobileNo.Text.Trim() };

                    dtUserData = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                    //if (fuPhoto.HasFile)
                    //{
                    //    //getting length of uploaded file
                    //    int length = fuPhoto.PostedFile.ContentLength;
                    //    //create a byte array to store the binary image data
                    //    imgbyte = new byte[length];
                    //    //store the currently selected file in memeory
                    //    HttpPostedFile img = fuPhoto.PostedFile;
                    //    //set the binary data
                    //    img.InputStream.Read(imgbyte, 0, length);
                    //}

                    if (dtUserData.HasRecords())
                    {
                        blResult = BL_Login.ModifyUser(dtUserData);

                        if (blResult)
                        {
                            // Response.Write("Udated Successfully");
                            strParameters = null;
                            strValues = null;

                            strParameters = new string[] { "USER_ID", "DOB", "JOB_POSTION" };

                            strValues = new string[] { lngUserId.ToString(), txtDOB.Text.Trim(), txtJobPosition.Text.Trim() };

                            dtUserProfile = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                            if (dtUserProfile.HasRecords())
                            {
                                blResult = BL_USER_PROFILE.Modify_User_profile(dtUserProfile);

                                if (blResult)
                                {
                                    lblresult.Text = lblName.Text + " Details Updated Successfully";
                                    lblresult.ForeColor = Color.Green;
                                    Response.Redirect("~/UserDetails.aspx");
                                }
                                else
                                {
                                    Response.Write("Update Failed");
                                    lblresult.Text = lblName.Text + " Updated Failed";
                                    lblresult.ForeColor = Color.Red;
                                    Response.Redirect("~/UserDetails.aspx");
                                }
                            }
                        }
                        else
                        {
                            Response.Write("Update Failed");
                            lblresult.Text = lblName.Text + " Updated Failed";
                            lblresult.ForeColor = Color.Red;
                            Response.Redirect("~/UserDetails.aspx");
                        }
                    }
                }
                else if (btnUpdate.Text == "DELETE")
                {
                    blResult = BL_USER_PROFILE.Remove_User_profile(UserSession.UserID, lngUserId);

                    if(blResult)
                    {
                        blResult = false;
                        blResult = BL_Login.Remove_User(UserSession.UserID, lngUserId);

                        if(blResult)
                        {
                            lblresult.Text = lblName.Text + " Details Updated Successfully";
                            lblresult.ForeColor = Color.Green;
                            Response.Redirect("~/UserDetails.aspx");
                        }
                        else
                        {
                            Response.Write("Delete operation Failed");
                            lblresult.Text = lblName.Text + " can not be delete";
                            lblresult.ForeColor = Color.Red;
                            Response.Redirect("~/UserDetails.aspx");
                        }
                    }
                    else
                    {
                        Response.Write("Delete operation Failed");
                        lblresult.Text = lblName.Text + " can not be delete";
                        lblresult.ForeColor = Color.Red;
                        Response.Redirect("~/UserDetails.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                lblresult.Text = ex.Message;
                lblresult.ForeColor = Color.Blue;
                Response.Redirect("~/UserDetails.aspx");
            }
        
            Get_Details();
        }
    }
}