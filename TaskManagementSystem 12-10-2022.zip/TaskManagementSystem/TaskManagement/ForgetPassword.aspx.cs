﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;


namespace TaskManagement
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                txtUserName.Focus();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            bool blResult = false;
            DataTable dtUserId;

            try
            {
                dtUserId = BL_Login.Get_User_Id(txtUserName.Text);

                if(dtUserId.HasRecords())
                {
                    blResult = BL_Login.ChangePassword(dtUserId.Rows[0]["USER_ID_PK"].ToLong(), txtNewPassword.Text.Trim());

                    if (blResult)
                    {
                        //txtMessage.Text = "Password changed successfully";
                        //this.ModalPopupExtender1.Show();
                        Response.Redirect("/Login.aspx", false);
                    }
                    else
                    {
                        //txtMessage.Text = "Failed to change Password";
                       // this.ModalPopupExtender1.Show();
                        Response.Redirect("~/ForgetPassword.aspx", false);
                    }
                }
                else
                {
                   // txtMessage.Text = "Invalid User";
                    //this.ModalPopupExtender1.Show();
                    Response.Redirect("~/Registration.aspx", false);
                }
            }
            catch (Exception ex)
            {
                //txtMessage.Text = "Failed to change Password";
                Console.WriteLine(ex.Message);
                //this.ModalPopupExtender1.Show();
                Response.Redirect("~/ForgetPassword.aspx", false);
            }
        }
    }
}