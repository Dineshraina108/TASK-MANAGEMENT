﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TaskManagement.WebPages
{
    public partial class UserStatusDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if(UserSession.UserID != 0)
                {
                    Get_UserStaus_Details();
                }
                else
                {
                    Response.Write("Please Login and see your status");
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

        private void Get_UserStaus(long UserId)
        {
            DataTable dtUserStatusDetails = new DataTable();

            try
            {
                dtUserStatusDetails = BL_Task.Get_User_Status(UserId);

                if (dtUserStatusDetails.HasRecords())
                {
                    grdUserStatus.DataSource = dtUserStatusDetails;
                    grdUserStatus.DataBind();

                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/Default.aspx");
            }
        }

        private void Get_UserStaus_Details()
        {
            DataTable dtUserStatusDetails = new DataTable();

            try
            {
                dtUserStatusDetails = BL_Task.Get_User_Status_Details(UserSession.UserID.ToLong());

                if (dtUserStatusDetails.HasRecords())
                {
                    grdUserStatus.DataSource = dtUserStatusDetails;
                    grdUserStatus.DataBind();

                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/Default.aspx");
            }
        }
    }
}