﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TaskManagement
{
    public class BL_Task
    {
        public static bool Create_Task(DataTable taskDetails)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_TASK_CODE", taskDetails.Rows[0]["TASK_CODE"].ToString()));
                lstInParam.Add(new SqlParameter("@P_TASK_DESC", taskDetails.Rows[0]["TASK_DESC"].ToString()));
                lstInParam.Add(new SqlParameter("@P_DURATION", taskDetails.Rows[0]["DURATION"].ToString()));
                lstInParam.Add(new SqlParameter("@P_CREATED_BY", taskDetails.Rows[0]["USER_ID"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CREATE_TASK", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static bool Modify_Task(DataTable taskDetails)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_TASK_ID", taskDetails.Rows[0]["TASK_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_TASK_CODE", taskDetails.Rows[0]["TASK_CODE"].ToString()));
                lstInParam.Add(new SqlParameter("@P_TASK_DESC", taskDetails.Rows[0]["TASK_DESC"].ToString()));
                lstInParam.Add(new SqlParameter("@P_DURATION", taskDetails.Rows[0]["DURATION"].ToString()));
                lstInParam.Add(new SqlParameter("@P_MODIFY_BY", taskDetails.Rows[0]["MODIFY_BY"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_MODIFY_TASK", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static bool Cancel_Task(long TaskId, long userId)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_TASK_ID", TaskId));
                lstInParam.Add(new SqlParameter("@P_CANCEL_BY", userId));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CANCEL_TASK", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static DataTable Get_Task_Details()
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_TASK_DETAILS", null, null);
        }

        public static DataTable Get_Task_Details(string duration)
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_TASKS", new string[] { "@P_DURATION" }, new string[] { duration });
        }

        public static DataTable Get_Duration()
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_DURATIONS", null, null);
        }

        public static DataTable Get_Task_Code()
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_TASK_CODE", null, null);
        }

        public static bool Create_User_Status(DataTable userStatusDetails)
        {
            var response = new AppResponse(ResponseStatus.FAILURE);

            try
            {
                List<SqlParameter> lstInParam = new List<SqlParameter>();
                List<SqlParameter> lstOutParam = new List<SqlParameter>();

                lstInParam.Add(new SqlParameter("@P_USER_ID", userStatusDetails.Rows[0]["USER_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_TASK_ID", userStatusDetails.Rows[0]["TASK_ID"].ToString()));
                lstInParam.Add(new SqlParameter("@P_START_TIME", userStatusDetails.Rows[0]["START_TIME"].ToString()));
                lstInParam.Add(new SqlParameter("@P_END_TIME", userStatusDetails.Rows[0]["END_TIME"].ToString()));
                lstInParam.Add(new SqlParameter("@P_WORKED_HOURS", userStatusDetails.Rows[0]["WORKED_HOURS"].ToString()));
                lstInParam.Add(new SqlParameter("@P_STATUS", userStatusDetails.Rows[0]["STATUS"].ToString()));
                lstInParam.Add(new SqlParameter("@P_ACTION", userStatusDetails.Rows[0]["ACTION"].ToString()));
                lstInParam.Add(new SqlParameter("@P_CREATED_BY", userStatusDetails.Rows[0]["USER_ID"].ToLong()));

                lstOutParam.Add(new SqlParameter("@P_RESULT", SqlDbType.BigInt));

                response = (new DataAccess()).DB_Live.Insert_or_Update_Data("SP_CREATE_USER_STATUS", lstInParam.ToArray(), lstOutParam.ToArray());

                if (response != null)
                {
                    if (response.ReturnData != null)
                    {
                        if (response.ReturnData["@P_RESULT"].ToLong() > 0)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;
            }

            return false;
        }

        public static DataTable Get_User_Status_Details(long  userId)
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_USER_STATUS", new string[] { "@P_USER_ID" }, new string[] { userId.ToString() });
        }

        public static DataTable Get_User_Status(long userId)
        {
            return (new DataAccess()).DB_Live.GetData("SP_GET_USER_STATUS_DETAILS", new string[] { "@P_USER_ID" }, new string[] { userId.ToString() });
        }


    }
}