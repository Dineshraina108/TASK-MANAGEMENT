﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TaskManagement.WebPages
{
    public partial class Task_Details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (UserSession.UserID == 0)
                    Response.Redirect("~/Login.aspx");

                ViewState["Filter"] = "ALL";
                Get_Task_Details();
            }
        }

        protected void grdTaskDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdTaskDetails.PageIndex = e.NewPageIndex;
            this.Get_Task_Details();
        }

        protected void DurationChanged(object sender, EventArgs e)
        {
            DropDownList ddlDuration = (DropDownList)sender;
            ViewState["Filter"] = ddlDuration.SelectedValue;
            this.Get_Task_Details();
        }

        private void Get_Task_Details()
        {
            DataTable dtTaskDetails = new DataTable();

            try
            {
                dtTaskDetails = BL_Task.Get_Task_Details(ViewState["Filter"].ToString());

                if(dtTaskDetails.HasRecords())
                {
                    grdTaskDetails.DataSource = dtTaskDetails;
                    grdTaskDetails.DataBind();

                    DropDownList ddlDuration = (DropDownList)grdTaskDetails.HeaderRow.FindControl("ddlDuration");
                    this.Get_Duration(ddlDuration);
                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/Task_Details.aspx");
            }
        }

        private void Get_Duration(DropDownList ddlDuration)
        {
            DataTable dtDurations;

            try
            {
                dtDurations = BL_Task.Get_Duration();

                if(dtDurations.HasRecords())
                {
                    ddlDuration.DataSource = dtDurations;
                    ddlDuration.DataTextField = "DURATION";
                    ddlDuration.DataValueField = "DURATION";
                    ddlDuration.DataBind();
                    ddlDuration.Items.FindByValue(ViewState["Filter"].ToString())
                                                         .Selected = true;
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/Task_Details.aspx");
            }
        }
    }
}