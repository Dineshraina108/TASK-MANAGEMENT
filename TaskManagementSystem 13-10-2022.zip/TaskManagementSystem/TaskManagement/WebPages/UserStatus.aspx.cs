﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Common;


namespace TaskManagement.WebPages
{
    public partial class UserStatus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (UserSession.UserID != 0)
                {
                    Get_Task_Codes();
                    Get_Status();
                    ddlTaskCode.Focus();
                }
                else
                {
                    Response.Write("Please Login and Add your status");
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DataTable dtUserStatus = new DataTable();
            string[] strParameters;
            string[] strValues;
            bool blResult = false;

            try
            {
                strParameters = new string[] { "USER_ID", "TASK_ID", "START_TIME", "END_TIME", "WORKED_HOURS", "STATUS", "ACTION" };

                strValues = new string[] { UserSession.UserID.ToString() , ddlTaskCode.SelectedValue.ToString(), txtStartTime.Text.Trim(), txtEndTime.Text.Trim(), txtWorkedHours.Text.Trim(),
                                            ddlStatus.Text, txtAction.Text.Trim() };

                dtUserStatus = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                if (dtUserStatus.HasRecords())
                {
                    blResult = BL_Task.Create_User_Status(dtUserStatus);

                    if (blResult)
                    {
                        Response.Write("User Status added Successfully");
                        Response.Redirect("~/WebPages/UserStatus.aspx", false);
                    }
                    else
                    {
                        Response.Write("Failed to add User status");
                        Response.Redirect("~/WebPages/UserStatus.aspx", false);
                    }
                }
                else
                {
                    Response.Write("User status add with out Details");
                    Response.Redirect("~/WebPages/UserStatus.aspx", false);
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/UserStatus.aspx", false);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Default.aspx");
        }

        private void Get_Status()
        {
            DataTable dtStatus = new DataTable();
            DataRow dr;

            try
            {
                dtStatus.Columns.Add("STATUS_ID");
                dtStatus.Columns.Add("DESCRIPTION");

                dr = dtStatus.NewRow();
                dr["STATUS_ID"] = 1;
                dr["DESCRIPTION"] = "COMPLETE";
                dtStatus.Rows.Add(dr);

                dr = dtStatus.NewRow();
                dr["STATUS_ID"] = 2;
                dr["DESCRIPTION"] = "IN COMPLETE";
                dtStatus.Rows.Add(dr);

                dtStatus.AcceptChanges();

                ddlStatus.DataSource = dtStatus;
                ddlStatus.DataTextField = "DESCRIPTION";
                ddlStatus.DataValueField = "STATUS_ID";
                ddlStatus.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/UserStatus.aspx", false);
            }
        }

        private void Get_Task_Codes()
        {
            DataTable dtTasks;

            try
            {
                dtTasks = BL_Task.Get_Task_Code();

                if(dtTasks.HasRecords())
                {
                    ddlTaskCode.DataSource = dtTasks;
                    ddlTaskCode.DataTextField = "TASK_CODE";
                    ddlTaskCode.DataValueField = "TASK_ID";
                    ddlTaskCode.DataBind();

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPages/UserStatus.aspx", false);
            }
        }
    }
}