﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using System.Configuration;
using Common;
using System.Data.SqlClient;

namespace TaskManagement.WebPages
{
    public partial class UserData : System.Web.UI.Page
    {
        private static int PageSize = 5;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserSession.UserID != 0)
            {
                BindDummyRow();
                Get_Details();
            }
            else
            {
                Response.Redirect("~/Login.aspx");
            }
        }

        private void BindDummyRow()
        {
            DataTable dummy = new DataTable();
            dummy.Columns.Add("USER_ID_PK");
            dummy.Columns.Add("CAREER_ID");
            dummy.Columns.Add("NAME");
            dummy.Columns.Add("DOB");
            dummy.Columns.Add("MOBILE_NO");
            dummy.Columns.Add("EMAIL_ID");
            dummy.Columns.Add("JOB_POSITION");
            dummy.Rows.Add();
            grdUserDetails.DataSource = dummy;
            grdUserDetails.DataBind();
        }

        private void Get_Details()
        {
            DataTable dtUserDetails = new DataTable();

            try
            {
                dtUserDetails = BL_Login.Get_User_Details();

                if (dtUserDetails.HasRecords())
                {
                    grdUserDetails.DataSource = dtUserDetails;
                    grdUserDetails.DataBind();
                }
                else
                {
                    Response.Write("No Users available");
                    Response.Redirect("~/Login.aspx");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPasges/UserData.aspx");
            }
        }

        [WebMethod]
        public static string Get_Users(string searchTerm, int pageIndex, int pageSize)
        {
            string query = "[SP_GET_SEARCHING_USER]";
            SqlCommand cmd = new SqlCommand(query);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@P_SEARCH_USER", searchTerm);
            cmd.Parameters.AddWithValue("@P_PAGE_INDEX", pageIndex);
            cmd.Parameters.AddWithValue("@P_PAGE_SIZE", pageSize);
            cmd.Parameters.Add("@P_RECORD_COUNT", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
            return GetData(cmd, pageIndex).GetXml();
        }

        private static DataSet GetData(SqlCommand cmd, int pageIndex)
        {
            string strConnString = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        sda.Fill(ds, "USERS");
                        DataTable dt = new DataTable("Pager");
                        dt.Columns.Add("PageIndex");
                        dt.Columns.Add("PageSize");
                        dt.Columns.Add("RecordCount");
                        dt.Rows.Add();
                        dt.Rows[0]["PageIndex"] = pageIndex;
                        dt.Rows[0]["PageSize"] = PageSize;
                        dt.Rows[0]["RecordCount"] = cmd.Parameters["@P_RECORD_COUNT"].Value;
                        ds.Tables.Add(dt);
                        return ds;
                    }
                }
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Reports/UserDetailsReport.aspx", false);
        }
    }
}