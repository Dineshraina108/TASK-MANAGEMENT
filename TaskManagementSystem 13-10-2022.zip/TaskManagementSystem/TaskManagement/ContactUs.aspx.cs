﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Net.Configuration;
using System.Configuration;
using System.Data;
using Common;

namespace TaskManagement
{
    public partial class ContactUs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                txtName.Focus();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DataTable dtContactDetails;
            string[] strParameters;
            string[] strValues;

            try
            {

                strParameters = new string[] { "NAME",  "MOBILE_NO" , "EMAIL_ID", "MESSAGE"};

                strValues = new string[] { txtName.Text.Trim(), txtMobileNo.Text.Trim(), txtEmaild.Text.Trim(), txtMessage.Text.Trim() };

                dtContactDetails = ExtensionMethods.CreateDataTableWithColumnandValues(strParameters, strValues);

                if(dtContactDetails.HasRecords())
                {
                    ExcelFiles.Get_Contact_Details(dtContactDetails);
                    Response.Write("Your Details are submitted");
                    Response.Redirect("~/Default.aspx", false);
                }
                else
                {
                    Response.Write("Your Details are not submitted");
                    Response.Redirect("~/ContactUs.aspx", false);
                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/ContactUs.aspx", false);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Default.aspx", false);
        }
    }
}