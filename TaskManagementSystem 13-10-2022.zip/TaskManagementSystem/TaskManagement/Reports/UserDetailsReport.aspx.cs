﻿using Common;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TaskManagement.Reports
{
    public partial class UserDetailsReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserSession.UserID != 0)
            {
               Get_Details();
            }
            else
            {
                Response.Redirect("~/Login.aspx");
            }
        }

        private void Generatereport(DataTable dt)
        {

            rvUserDetails.Visible = true;
            rvUserDetails.SizeToReportContent = true;

            rvUserDetails.LocalReport.ReportPath = Server.MapPath("~/Reports/RptUserDetails.rdlc");

            rvUserDetails.LocalReport.DataSources.Clear(); 

            ReportDataSource _rsource = new ReportDataSource("dsUsers", dt);

            rvUserDetails.LocalReport.DataSources.Add(_rsource);

            rvUserDetails.LocalReport.Refresh();

        }

        private void Get_Details()
        {
            DataTable dtUserDetails = new DataTable();

            try
            {
                dtUserDetails = BL_Login.Get_User_Details();

                if (dtUserDetails.HasRecords())
                {
                    Generatereport(dtUserDetails);
                }
                else
                {
                    Response.Write("No Users available");
                    Response.Redirect("~/Login.aspx");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Response.Redirect("~/WebPasges/UserData.aspx");
            }
        }
    }
}