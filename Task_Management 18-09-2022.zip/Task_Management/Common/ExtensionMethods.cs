﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using Common;
using System.Text.RegularExpressions;

namespace Common
{
    public static class ExtensionMethods
    {

        public static bool HasRecords(this DataTable dt)
        {
            if (object.ReferenceEquals(dt, null)) //dt == null
                return false;
            else if (dt.Rows.Count == 0)
                return false;

            return true;
        }

        public static string ConcatenateWithComma(this string Value, object ValuetoConcatenate)
        {
            if (ValuetoConcatenate == null)
            {
                return "";
            }
            else if (ValuetoConcatenate.ToString() != "")
            {
                if (Value == null)
                {
                    return ValuetoConcatenate.ToString();
                }
                else if (Value == "")
                {
                    return ValuetoConcatenate.ToString();
                }
                else
                {
                    return Value + "," + ValuetoConcatenate;
                }
            }

            return "";
        }

        public static string Concatenate(this string Value, object ValuetoConcatenate, char SeparatingCharacter)
        {
            if (ValuetoConcatenate == null)
            {
                return "";
            }
            else if (ValuetoConcatenate.ToString() != "")
            {
                if (Value == "" || Value == null)
                {
                    return ValuetoConcatenate.ToString();
                }
                else
                {
                    return Value + SeparatingCharacter + ValuetoConcatenate;
                }
            }

            return "";
        }

        public static string GetDescription(this Enum GenericEnum)
        {
            Type genericEnumType = GenericEnum.GetType();
            MemberInfo[] memberInfo = genericEnumType.GetMember(GenericEnum.ToString());
            if ((memberInfo != null && memberInfo.Length > 0))
            {
                var _Attribs = memberInfo[0].GetCustomAttributes(typeof(System.ComponentModel.DescriptionAttribute), false);
                if ((_Attribs != null && _Attribs.Count() > 0))
                {
                    return ((System.ComponentModel.DescriptionAttribute)_Attribs.ElementAt(0)).Description;
                }
            }
            return GenericEnum.ToString();
        }    

        public static string PascalCase(this string value)
        {
            string strReturnValue = string.Empty;

            try
            {
                if (string.IsNullOrEmpty(value))
                {
                    return string.Empty;
                }
                else
                    value = value.ToLower();

                string[] strWords = value.Split(' ');
                char[] chrValue;

                foreach (string word in strWords)
                {
                    if (word.Trim() != string.Empty)
                    {
                        chrValue = word.ToCharArray();
                        chrValue[0] = char.ToUpper(chrValue[0]);

                        strReturnValue = strReturnValue + new string(chrValue) + " ";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strReturnValue.Trim().ToString();
        }

        [Obsolete("")]

        public static string GetStringValue(this object Value)
        {
            if (Value == null)
                return "";
            else if (Convert.IsDBNull(Value))
                return "";
            else if (Value.ToString() == "")
                return "";
            else
                return Value.ToString();
        }

        public static bool ToBool(this object Value)
        {
            if (Value == null)
                return false;
            else if (Convert.IsDBNull(Value))
                return false;
            else if (Value.ToString() == "")
                return false;
            else if (Value.ToString() == "0")
                return false;
            else
                return true;
        }

        public static Double ToDouble(this object Value)
        {
            if (Value == null)
                return 0;
            else if (Convert.IsDBNull(Value))
                return 0;
            else if (Value.ToString() == "")
                return 0;
            else if (Value.ToString() == ".")
                return 0;
            else
                return Convert.ToDouble(Value.ToString());
        }

        public static long ToLong(this object Value)
        {
            if (Value == null)
                return 0;
            else if (Convert.IsDBNull(Value))
                return 0;
            else if (Value.ToString() == "")
                return 0;
            else if (Value.ToString() == ".")
                return 0;
            else
                return Convert.ToInt64(Value.ToString());
        }

        public static bool IsNothingOrDBNull(object objVal)
        {
            if (objVal == null)
            {
                return true;
            }
            else if (Convert.IsDBNull(objVal))
            {
                return true;
            }
            else if (objVal.ToString() == "")
            {
                return true;
            }

            return false;
        }

        public static void FillComboBoxWithSelectedValue(this DropDownList cboName, DataTable dataSource, string displayMemberName, string valueMembername, string defaultSelectedText = "")
        {
            cboName.DataSource = dataSource;
            cboName.DataTextField = displayMemberName;
            cboName.DataValueField = valueMembername;

            if (defaultSelectedText != "")
            {
                //cboName.SelectedIndex = cboName.Items.IndexOf(cboName.Items.FindByValue("x")); // If you want to find text by value field.
                cboName.SelectedIndex = cboName.Items.IndexOf(cboName.Items.FindByText(defaultSelectedText));// If you want to find text by TextField.
            }
        }

        public static void FillComboBoxWithSelectedIndex(this DropDownList cboName, DataTable dataSource, string displayMemberName, string valueMembername, int defaultSelectedIndex = -1)
        {
            cboName.DataSource = dataSource;
            cboName.DataTextField = displayMemberName;
            cboName.DataValueField = valueMembername;

            if (defaultSelectedIndex != -1)
            {
                cboName.SelectedIndex = defaultSelectedIndex;
            }
        }

        public static void FillComboBoxWithStartText(this DropDownList cboName, List<string> dataSource, string defaultSelectedText = "")
        {
            cboName.DataSource = dataSource;

            if (defaultSelectedText != "")
            {
                cboName.SelectedIndex = cboName.Items.IndexOf(cboName.Items.FindByText(defaultSelectedText));// If you want to find text by TextField.
            }
        }

        public static void FillComboBoxWithStartIndex(this DropDownList cboName, List<string> dataSource, int defaultSelectedIndex = -1)
        {
            cboName.DataSource = dataSource;

            if (defaultSelectedIndex != -1)
            {
                cboName.SelectedIndex = defaultSelectedIndex;
            }
        }

        public static DataTable CreateDataTable(this GridView grid)
        {
            DataTable dtData = null;

            if (grid.Columns.Count > 0)
            {
                dtData = new DataTable();

                if (grid.HeaderRow != null)
                {
                    for (int i = 0; i < grid.HeaderRow.Cells.Count; i++)
                    {
                        dtData.Columns.Add(grid.HeaderRow.Cells[i].Text);
                    }
                }

                //  add each of the data rows to the table
                foreach (GridViewRow row in grid.Rows)
                {
                    DataRow dr;
                    dr = dtData.NewRow();

                    for (int i = 0; i < row.Cells.Count; i++)
                    {
                        dr[i] = row.Cells[i].Text.Replace("&nbsp;", "");
                    }
                    dtData.Rows.Add(dr);
                }

            }

            return dtData;
        }

        public static DataTable ConvertListToDataTable<T>(IList<T> list)
        {
            DataTable table = new DataTable();
            FieldInfo[] fields = list.GetType().GetFields();
            try
            {
                if (list.Count > 0)
                {
                    if (typeof(T).Name.ToUpper() == "STRING" || typeof(T).IsPrimitive)
                    {
                        table.Columns.Add(new DataColumn(typeof(T).Name.ToUpper()));

                        foreach (T item in list)
                        {
                            DataRow row = table.NewRow();

                            row[0] = item;

                            table.Rows.Add(row);
                        }
                    }
                    else
                    {
                        foreach (PropertyInfo info in list[0].GetType().GetProperties())
                        {
                            if ((info.PropertyType).IsPrimitive || info.PropertyType.Name == "String")
                            {
                                table.Columns.Add(new DataColumn(info.Name, info.PropertyType));
                            }
                        }

                        foreach (T item in list)
                        {
                            DataRow row = table.NewRow();

                            foreach (DataColumn dc in table.Columns)
                            {
                                row[dc.ColumnName] = item.GetType().GetProperty(dc.ColumnName).GetValue(item, null);
                            }

                            table.Rows.Add(row);
                        }
                    }
                }
                else
                {
                    table = null;
                }
            }
            catch (Exception ex)
            { }
            return table;
        }

        public static DataTable ClassToDataTable<T>(this IEnumerable<T> source)
        {
            DataTable dt = new DataTable();
            var props = TypeDescriptor.GetProperties(typeof(T));

            foreach (PropertyDescriptor prop in props)
            {
                DataColumn dc = dt.Columns.Add(prop.Name, prop.PropertyType);
                dc.Caption = prop.DisplayName;
                dc.ReadOnly = prop.IsReadOnly;
            }
            foreach (T item in source)
            {
                DataRow dr = dt.NewRow();
                foreach (PropertyDescriptor prop in props)
                {
                    dr[prop.Name] = prop.GetValue(item);
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }

        public static void AddColumnsToDataTable(string[] Columns, DataTable dt)
        {
            try
            {
                if (dt.Columns.Count <= 0)
                {
                    foreach (string col in Columns)
                    {
                        dt.Columns.Add(col);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static object AddColumnsToDataTable(DataTable dt, GridView Grid, string[] Columns = null)
        {
            DataColumn dcNew;

            try
            {
                // Add Columns from RadGrid
                if (dt.Columns.Count == 0)
                {
                    if (Columns == null)
                    {
                        for (int intIndex = 0; intIndex <= Grid.Columns.Count - 1; intIndex++)
                        {
                            if (((BoundField)Grid.Columns[intIndex]).ReadOnly != true)
                            {
                                //dcNew = new DataColumn();
                                //dcNew.ColumnName = Grid.Columns[intIndex].Name;

                                ////if (Grid.Columns[intIndex] is GridViewDecimalColumn)
                                ////    dcNew.DataType = typeof(System.Double);

                                //dt.Columns.Add(dcNew);

                                if (Grid.HeaderRow != null)
                                {
                                    for (int i = 0; i < Grid.HeaderRow.Cells.Count; i++)
                                    {
                                        dt.Columns.Add(Grid.HeaderRow.Cells[i].Text);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int intIndex = 0; intIndex <= Columns.Count() - 1; intIndex++)
                        {
                            dt.Columns.Add(Columns[intIndex]);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CreateDataTableWithGridandParameter(GridView Grid, string[] strParameters = null)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            try
            {
                // If DataTable Dosen't Contain Column  Add Column
                dt.Rows.Clear();
                if (dt.Columns.Count == 0)
                {
                    AddColumnsToDataTable(dt, Grid, strParameters);
                }

                for (int intRow = 0; intRow <= Grid.Rows .Count - 1; intRow++)
                {
                    dr = dt.NewRow();
                    // Adding a Row
                    for (int intColumn = 0; intColumn <= dt.Columns.Count - 1; intColumn++)
                    {
                        dr[dt.Columns[intColumn].ColumnName] = Grid.Rows[intRow].Cells[dt.Columns[intColumn].Ordinal].GetStringValue();
                    }
                    dt.Rows.Add(dr);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Obsolete("Use public static DataTable CreateDataTable(Dictionary<string, string> data)")]
        public static DataTable CreateDataTableWithColumnandValues(string[] Columns, string[] Value)
        {
            DataTable dt = new DataTable();
            DataRow dr;

            try
            {
                // Create Columns
                AddColumnsToDataTable(Columns, dt);
                dr = dt.NewRow();
                for (int intIndex = 0; intIndex <= dt.Columns.Count - 1; intIndex++)
                {
                    dr[intIndex] = Value[intIndex];
                }
                dt.Rows.Add(dr);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CreateDataTableWithDictionary(Dictionary<string, string> data)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            DataColumn dc;

            try
            {
                dr = dt.NewRow();

                foreach (KeyValuePair<string, string> kvp in data)
                {
                    dc = new DataColumn(kvp.Key);
                    dt.Columns.Add(dc);
                }

                foreach (KeyValuePair<string, string> kvp in data)
                {
                    dr[kvp.Key] = kvp.Value;
                }

                dt.Rows.Add(dr);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable GetUpdatedData(DataTable SourceTable, DataTable updatedTable, string PrimaryKeyColumnName)
        {
            DataTable dtTemp = SourceTable.Copy();
            DataTable dtResult = updatedTable.Clone();

            DataView originalView = SourceTable.DefaultView;
            string[] strColumnNames;
            DataRow rtRow;

            strColumnNames = (from dc in updatedTable.Columns.Cast<DataColumn>()
                              select dc.ColumnName).ToArray();

            dtTemp = originalView.ToTable(true, strColumnNames);

            dtTemp.PrimaryKey = new DataColumn[] { dtTemp.Columns[PrimaryKeyColumnName] };
            updatedTable.PrimaryKey = new DataColumn[] { updatedTable.Columns[PrimaryKeyColumnName] };

            if (updatedTable.Rows.Count > 0)
            {
                for (int i = 0; i <= updatedTable.Rows.Count - 1; i++)
                {
                    //If the source table has the record in the updated table, 
                    //then check if it is updated or not, to include in the return datatable.
                    if (dtTemp.Rows.Find(updatedTable.Rows[i][PrimaryKeyColumnName]) != null)
                    {
                        var sourceArray = dtTemp.Rows.Find(updatedTable.Rows[i][PrimaryKeyColumnName]).ItemArray;
                        var checkArray = updatedTable.Rows[i].ItemArray;

                        //Wrote the new Comparer as the default one does consider the datatype
                        //Like, it returns false when compares a numeric data as number format in one object and as string type in another object
                        //Ex: Condition 1 = "1" results as false. But we need to return true
                        //if (!sourceArray.ToArray.SequenceEqual(checkArray.ToArray, new DataRowComparer()))
                        if (!sourceArray.SequenceEqual(checkArray.ToArray(), new DataRowComparer()))
                        {
                            rtRow = dtResult.NewRow();
                            rtRow.ItemArray = checkArray;
                            dtResult.Rows.Add(rtRow);
                        }
                    }
                }
            }

            return dtResult;
        }

        public static DataTable GetUpdatedData(DataTable SourceTable, DataTable updatedTable, string[] PrimaryKeyColumnNames)
        {
            DataTable dtTemp = SourceTable.Copy();
            DataTable dtResult = updatedTable.Clone();
            List<DataColumn> tempPK, updatedPK;
            DataView originalView = SourceTable.DefaultView;
            string[] strColumnNames;
            DataRow rtRow;
            List<object> data;

            strColumnNames = (from dc in updatedTable.Columns.Cast<DataColumn>()
                              select dc.ColumnName).ToArray();

            dtTemp = originalView.ToTable(true, strColumnNames);

            tempPK = new List<DataColumn>();
            updatedPK = new List<DataColumn>();

            foreach (string PrimaryKeyColumnName in PrimaryKeyColumnNames)
            {
                tempPK.Add(dtTemp.Columns[PrimaryKeyColumnName]);
                updatedPK.Add(updatedTable.Columns[PrimaryKeyColumnName]);
            }

            dtTemp.PrimaryKey = tempPK.ToArray();   // new DataColumn[] { dtTemp.Columns[PrimaryKeyColumnName] };
            updatedTable.PrimaryKey = updatedPK.ToArray();  // new DataColumn[] { updatedTable.Columns[PrimaryKeyColumnName] };

            if (updatedTable.Rows.Count > 0)
            {
                for (int i = 0; i <= updatedTable.Rows.Count - 1; i++)
                {
                    data = new List<object>();

                    foreach (string PrimaryKeyColumnName in PrimaryKeyColumnNames)
                    {
                        data.Add(updatedTable.Rows[i][PrimaryKeyColumnName]);
                    }

                    //If the source table has the record in the updated table, 
                    //then check if it is updated or not, to include in the return datatable.
                    //if (dtTemp.Rows.Find(updatedTable.Rows[i][PrimaryKeyColumnName]) != null)
                    if (dtTemp.Rows.Find(data.ToArray()) != null)
                    {
                        //var sourceArray = dtTemp.Rows.Find(updatedTable.Rows[i][PrimaryKeyColumnName]).ItemArray;
                        var sourceArray = dtTemp.Rows.Find(data.ToArray()).ItemArray;
                        var checkArray = updatedTable.Rows[i].ItemArray;

                        //Wrote the new Comparer as the default one does consider the datatype
                        //Like, it returns false when compares a numeric data as number format in one object and as string type in another object
                        //Ex: Condition 1 = "1" results as false. But we need to return true
                        //if (!sourceArray.ToArray.SequenceEqual(checkArray.ToArray, new DataRowComparer()))
                        if (!sourceArray.SequenceEqual(checkArray.ToArray(), new DataRowComparer()))
                        {
                            rtRow = dtResult.NewRow();
                            rtRow.ItemArray = checkArray;
                            dtResult.Rows.Add(rtRow);
                        }
                    }
                }
            }

            return dtResult;
        }

        private class DataRowComparer : IEqualityComparer<object>
        {
            public bool Equals(object x, object y)
            {
                bool xNumberCheck, yNumberCheck;
                double xNumericValue, yNumericValue;

                if (Convert.IsDBNull(x) & !Convert.IsDBNull(y) & y.ToString() != "")
                {
                    return false;
                }
                else if (!Convert.IsDBNull(x) & x.ToString() != "" & Convert.IsDBNull(y))
                {
                    return false;
                }
                else if (x.ToString() != y.ToString())
                {
                    xNumberCheck = Double.TryParse(x.ToString(), out xNumericValue);
                    yNumberCheck = Double.TryParse(y.ToString(), out yNumericValue);

                    if (xNumberCheck && yNumberCheck)
                    {
                        if (xNumericValue == yNumericValue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }

                    return false;
                }

                return true;
            }

            public int GetHashCode(object obj)
            {
                throw new NotImplementedException();
            }
        }

        public static T GetEnumVal<T>(string value)
        {
            if (value == "")
            {
                return GetEnumVal<T>(0);
            }
            else
            {
                return (T)Enum.Parse(typeof(T), value, true);
            }
        }

        public static T GetEnumVal<T>(int value)
        {
            return (T)Enum.GetValues(typeof(T)).GetValue(value);
        }

        private static String[] units = { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };

        private static String[] tens = { "", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

        public static String NumberInWords(double amount)
        {
            try
            {
                Int64 amount_int = (Int64)amount;
                Int64 amount_dec = (Int64)Math.Round((amount - (double)(amount_int)) * 100);

                if (amount_dec == 0)
                {
                    return NumberToWords(amount_int) + " Only.";
                }
                else
                {
                    return NumberToWords(amount_int) + " and " + NumberToWords(amount_dec) + " Paise Only.";
                }
            }
            catch (Exception e)
            {
                // TODO: handle exception
                throw e;
            }
        }

        private static String NumberToWords(Int64 i)
        {
            if (i < 20)
            {
                return units[i];
            }
            if (i < 100)
            {
                return tens[i / 10] + ((i % 10 > 0) ? " " + NumberToWords(i % 10) : "");
            }
            if (i < 1000)
            {
                return units[i / 100] + " Hundred"
                        + ((i % 100 > 0) ? " And " + NumberToWords(i % 100) : "");
            }
            if (i < 100000)
            {
                return NumberToWords(i / 1000) + " Thousand "
                + ((i % 1000 > 0) ? " " + NumberToWords(i % 1000) : "");
            }
            if (i < 10000000)
            {
                return NumberToWords(i / 100000) + " Lakhs "
                        + ((i % 100000 > 0) ? " " + NumberToWords(i % 100000) : "");
            }
            if (i < 1000000000)
            {
                return NumberToWords(i / 10000000) + " Crores "
                        + ((i % 10000000 > 0) ? " " + NumberToWords(i % 10000000) : "");
            }
            return NumberToWords(i / 1000000000) + " Arab "
                    + ((i % 1000000000 > 0) ? " " + NumberToWords(i % 1000000000) : "");
        }

        public static int GetExcelColumnNumber(string columnName)
        {
            if (string.IsNullOrEmpty(columnName))
                throw new ArgumentNullException("Invalid column name parameter");

            columnName = columnName.ToUpperInvariant();

            int sum = 0;

            char ch;
            for (int i = 0; i < columnName.Length; i++)
            {
                ch = columnName[i];

                if (char.IsDigit(ch))
                    throw new ArgumentNullException("Invalid column name parameter on character " + ch);

                sum *= 26;
                sum += (ch - 'A' + 1);
                //sum += (columnName[i] - 'A');
            }

            return sum;
        }

        public static string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }

        public static string SplitLargeStringIntoLines(string Party, int maximumLineLength)
        {
            return Regex.Replace(Party, @"(.{1," + maximumLineLength + @"})(?:\s|$)", "$1\n");
        }

    }
}
