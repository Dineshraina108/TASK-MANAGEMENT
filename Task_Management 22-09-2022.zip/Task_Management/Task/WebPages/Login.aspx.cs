﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Common;
using System.Configuration;
//using System.Windows.Forms;
using System.Net;
using System.Web.Security;

namespace Task
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                txtUserName.Text = "";
                txtPassword.Text = "";
                txtUserName.Focus();
            }
        }

        protected void lbregister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void lbforgetpass_Click(object sender, EventArgs e)
        {
            Response.Redirect("ForgetPassword.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string strUserName = "", strPassword = "";
            bool blnIsValid = false;

            try
            {
                strUserName = txtUserName.Text.Trim();
                strPassword = txtPassword.Text.Trim();

                blnIsValid = BL_Login.CHECK_USER_IS_VALID(strUserName, strPassword);

                if(blnIsValid)
                {
                    Session["Username"] = txtUserName.Text;
                    Response.Write("SUCCESS");
                   // MessageBox.Show("Login Successfully","Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Response.Redirect("~/Default.aspx", false);
                    //FormsAuthentication.SetAuthCookie(strUserName, false);
                    //Response.Redirect(Request.QueryString["Default.aspx"]);
                }
                else
                {
                    Response.Write("Invalid Username or Password");
                    // MessageBox.Show("Invalid Username or Password", "Falid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Server.TransferRequest(Request.Url.AbsolutePath, false);
                    txtUserName.Focus();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                // MessageBox.Show(ex.Message,"Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Server.TransferRequest(Request.Url.AbsolutePath, false);
                txtUserName.Focus();
            }
        }
    }
}