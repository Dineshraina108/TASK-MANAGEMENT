﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Common
{
    public class DataHelper
    {
        string ConnectionString = "";
        SqlTransaction Trans;
        bool IsOpenTransaction;
        SqlConnection Con;
        int RetryLimit;
        AppResponse response;

        public DataHelper(string ConnString)
        {
            ConnectionString = ConnString;
            RetryLimit = 5;
        }

        public DataHelper(string ConnString, int AttemptsToRetryConnection)
        {
            ConnectionString = ConnString;
            RetryLimit = AttemptsToRetryConnection;
        }

        public AppResponse OpenConnection()
        {
            int intRetryCount = 0;
            //bool blnopenConnection = false;
            response = new AppResponse();

            try
            {
                Retry:
                //if (Con == null)
                {
                    Con = new SqlConnection();
                    Con.ConnectionString = ConnectionString;
                }

                if (Con.State != ConnectionState.Open)
                    Con.Open();
                //else if (Con.State == ConnectionState.Open)
                //    return true;

                //Test the Connection, if it is really connected.
                try
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT 1", Con))
                    {
                        int intValue;
                        intValue = Convert.ToInt32(cmd.ExecuteScalar());
                        response.Status = ResponseStatus.SUCCESS;
                    }
                }
                catch (Exception ex)
                {
                    //if (Con.State == ConnectionState.Open)
                    //    Con.Close();

                    //Con = new OracleConnection();
                    //Con.ConnectionString = ConnectionString;

                    intRetryCount = intRetryCount + 1;

                    if (intRetryCount <= RetryLimit)
                    {
                        Con.Dispose();
                        //Con = new OracleConnection(ConnectionString);

                        goto Retry;
                    }
                    else
                    {
                        throw new DBConnectionException("Could not connect to the Database server. Close and Login again");
                    }
                }

                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool CloseConnection()
        {
            bool blnCloseConnection = false;

            try
            {
                // Close the Connection
                if (Con.State == ConnectionState.Open)
                {
                    //DO NOT Close if there is any open transaction
                    if (!IsOpenTransaction)
                    {
                        Con.Close();
                        blnCloseConnection = true;
                    }
                }
            }
            catch (Exception ex)
            {
                blnCloseConnection = false;
            }

            return blnCloseConnection;
        }

        public DataTable GetData(string SqlString)
        {
            DataTable dt = new DataTable();

            try
            {
                if (OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    using (SqlCommand cmd = new SqlCommand(SqlString, Con))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt);
                        }
                    }

                    CloseConnection();
                }
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return dt;
        }

        [Obsolete("Use GetData(string procedureName, List<SqlParameter> inputParameters)")]

        public DataTable Get_Data_With_Inputs_Only(string procedureName, string[] parameterNames, string[] parameterValues)
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            SqlParameter parameter;
            SqlDataAdapter da = new SqlDataAdapter();

            try
            {
                if (procedureName != null)
                {
                    if (OpenConnection().Status == ResponseStatus.SUCCESS)
                    {
                        cmd = new SqlCommand(procedureName, Con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (parameterNames != null)
                        {
                            for (int intItem = 0; intItem <= parameterNames.Count() - 1; intItem++)
                            {
                                //Create and Add Values on Parameters
                                parameter = new SqlParameter(parameterNames[intItem], parameterValues[intItem]);
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        // Execution
                        da = new SqlDataAdapter(cmd);
                        da.Fill(dt);

                        CloseConnection();
                    }
                }
            }

            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return dt;
        }
        public DataTable GetData(string procedureName, string[] parameterNames, string[] parameterValues)
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            SqlParameter parameter;
            SqlDataAdapter da = new SqlDataAdapter();

            try
            {
                if (procedureName != null)
                {
                    if (OpenConnection().Status == ResponseStatus.SUCCESS)
                    {
                        cmd = new SqlCommand(procedureName, Con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (parameterNames != null)
                        {
                            for (int intItem = 0; intItem <= parameterNames.Count() - 1; intItem++)
                            {
                                //Create and Add Values on Parameters
                                parameter = new SqlParameter(parameterNames[intItem], parameterValues[intItem]);
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        cmd.Parameters.Add("OUTPUT", SqlDbType.VarChar);
                        cmd.Parameters["OUTPUT"].Direction = ParameterDirection.Output;

                        // Execution
                        da = new SqlDataAdapter(cmd);
                        da.Fill(dt);

                        CloseConnection();
                    }
                }
            }

            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return dt;
        }

        public DataTable GetData(string procedureName, List<SqlParameter> inputParameters)
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();

            try
            {
                if (procedureName != null)
                {
                    if (OpenConnection().Status == ResponseStatus.SUCCESS)
                    {
                        cmd = new SqlCommand(procedureName, Con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (inputParameters?.Any() == true)
                        {
                            foreach (SqlParameter parameter in inputParameters)
                            {
                                parameter.Direction = ParameterDirection.Input;
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        cmd.Parameters.Add("OUTPUT", SqlDbType.VarChar);
                        cmd.Parameters["OUTPUT"].Direction = ParameterDirection.Output;

                        da = new SqlDataAdapter(cmd);
                        da.Fill(dt);

                        CloseConnection();
                    }
                }
            }

            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return dt;
        }

        [Obsolete("Use GetData(string procedureName, List<SqlParameter> inputParameters, string[] outParamNames)")]
        public DataSet GetDataSet(string ProcedureName, string[] strParameterNames, string[] strParameterValues, string[] strOutParamNames)
        {
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand();
            SqlParameter parameter;
            SqlDataAdapter da = new SqlDataAdapter();

            try
            {
                if (ProcedureName != null)
                {
                    if (OpenConnection().Status == ResponseStatus.SUCCESS)
                    {
                        cmd = new SqlCommand(ProcedureName, Con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (strParameterNames != null)
                        {
                            for (int intItem = 0; intItem <= strParameterNames.Count() - 1; intItem++)
                            {
                                //Create and Add Values on Parameters
                                parameter = new SqlParameter(strParameterNames[intItem], strParameterValues[intItem]);
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        if (strOutParamNames != null)
                        {
                            for (int index = 0; index < strOutParamNames.Count(); index++)
                            {
                                parameter = new SqlParameter(strOutParamNames[index], SqlDbType.VarChar);
                                parameter.Direction = ParameterDirection.Output;
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        // Execution
                        da = new SqlDataAdapter(cmd);
                        da.Fill(ds);

                        CloseConnection();
                    }
                }
            }

            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return ds;
        }

        public DataSet GetDataSet(string procedureName, List<SqlParameter> inputParameters, string[] outParamNames)
        {
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();

            try
            {
                if (procedureName != null)
                {
                    if (OpenConnection().Status == ResponseStatus.SUCCESS)
                    {
                        cmd = new SqlCommand(procedureName, Con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (inputParameters?.Any() == true)
                        {
                            foreach (SqlParameter parameter in inputParameters)
                            {
                                parameter.Direction = ParameterDirection.Input;
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        if (outParamNames != null)
                        {
                            for (int index = 0; index < outParamNames.Count(); index++)
                            {
                                SqlParameter parameter = new SqlParameter(outParamNames[index], SqlDbType.VarChar);
                                parameter.Direction = ParameterDirection.Output;
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        da = new SqlDataAdapter(cmd);
                        da.Fill(ds);

                        CloseConnection();
                    }
                }
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return ds;
        }

        public DataSet GetDataSet(string procedureName, List<SqlParameter> inputParameters, int NumberOf_ResultSets)
        {
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand();

            SqlDataAdapter da = new SqlDataAdapter();

            try
            {
                if (procedureName != null)
                {
                    if (OpenConnection().Status == ResponseStatus.SUCCESS)
                    {
                        cmd = new SqlCommand(procedureName, Con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (inputParameters?.Any() == true)
                        {
                            foreach (SqlParameter parameter in inputParameters)
                            {
                                parameter.Direction = ParameterDirection.Input;
                                cmd.Parameters.Add(parameter);
                            }
                        }

                        for (int index = 0; index < NumberOf_ResultSets; index++)
                        {
                            cmd.Parameters.Add("OUTPUT", SqlDbType.VarChar);
                            cmd.Parameters["OUTPUT"].Direction = ParameterDirection.Output;
                        }

                        da = new SqlDataAdapter(cmd);
                        da.Fill(ds);

                        CloseConnection();
                    }
                }
            }

            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return ds;
        }

        public T ExecuteScalar<T>(string SqlQuery)
        {
            object Value = null;

            try
            {
                if (OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    using (SqlCommand cmd = new SqlCommand(SqlQuery, Con))
                    {
                        Value = cmd.ExecuteScalar();
                    }

                    CloseConnection();
                }

                if (Convert.IsDBNull(Value) == false)
                {
                    return (T)Convert.ChangeType(Value, typeof(T));
                }
                else
                {
                    return default(T);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool BulkInsert(string TableName, DataTable DataToInsert)
        {
            SqlBulkCopy bulk = new SqlBulkCopy(Con);
         
            try
            {
                //bulk.BU = OracleBulkCopyOptions.UseInternalTransaction;
                bulk.DestinationTableName = TableName;
                
                using (SqlTransaction sqlTransaction = Con.BeginTransaction())
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(Con, SqlBulkCopyOptions.Default, sqlTransaction))
                    {
                        //Set the database table name
                        sqlBulkCopy.DestinationTableName = TableName;

                        //[OPTIONAL]: Map the DataTable columns with that of the database table
                      
                        try
                        {
                            bulk.WriteToServer(DataToInsert);
                            sqlTransaction.Commit();
                        }
                        catch
                        {
                            sqlTransaction.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        [Obsolete("Use Insert_UpdateData(string procedureName, SqlParameter[] inParameters, SqlParameter[] outParameters")]

        public bool Insert_or_Update_Data(string procedureName, string[] parameterNames, string[] paramValues)
        {
            SqlCommand cmd = new SqlCommand();
            SqlParameter parameter;
            int intItem;

            try
            {
                if (procedureName != null && OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    cmd = new SqlCommand(procedureName, Con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    for (intItem = 0; intItem <= parameterNames.Count() - 1; intItem++)
                    {
                        //Create and Add Values on Parameters
                        parameter = new SqlParameter(Convert.ToString(parameterNames[intItem]), paramValues[intItem]);
                        cmd.Parameters.Add(parameter);
                    }

                    // Execution
                    if (cmd.ExecuteNonQuery() == 0)
                        return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Insert_or_Update_Data(string Procedure, DataTable dtdata)
        {
            SqlCommand cmd = new SqlCommand();
            SqlParameter parameter;
            try
            {
                if (Procedure != null && OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    cmd = new SqlCommand(Procedure, Con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    // Get Each Row  
                    foreach (DataRow row in dtdata.Rows)
                    {
                        cmd = new SqlCommand(Procedure, Con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        // Get Each Columns  and add to Parameters
                        foreach (DataColumn column in dtdata.Columns)
                        {
                            //Create and Add Values on Parameters
                            parameter = new SqlParameter(column.ToString(), row[column.ToString()]);
                            cmd.Parameters.Add(parameter);
                        }
                        // Execution
                        if (cmd.ExecuteNonQuery() == 0)
                            return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public AppResponse Insert_or_Update_Data(string procedureName, SqlParameter[] inParameters, SqlParameter[] outParameters)
        {
            AppResponse response = new AppResponse(ResponseStatus.FAILURE);
            SqlCommand cmd = new SqlCommand();

            try
            {
                if (procedureName != null && OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    InitiateTransaction();

                    cmd = new SqlCommand(procedureName, Con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (SqlParameter param in inParameters)
                    {
                        //Create and Add Values on Parameters
                        param.Direction = ParameterDirection.Input;
                        cmd.Parameters.Add(param);
                    }

                    if (outParameters != null)
                    {
                        foreach (SqlParameter param in outParameters)
                        {
                            //Create and Add Values on Parameters
                            param.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(param);
                        }
                    }

                    cmd.ExecuteNonQuery();

                    if (outParameters != null)
                    {
                        response.ReturnData = new Dictionary<object, object>();

                        foreach (SqlParameter param in outParameters)
                        {
                            response.ReturnData.Add(param.ParameterName, param.Value);
                        }
                    }

                    CommitTransaction();

                    response.Status = ResponseStatus.SUCCESS;
                }
            }
            catch (Exception ex)
            {
                if (Con != null)
                {
                    if (Con.State == ConnectionState.Open)
                        RollbackTransaction();
                }

                throw ex;
            }

            return response;
        }

        //public AppResponse InsertData(string MasterQuery, DataTable MasterData, string ChildQuery, DataTable ChildData, string UpdateAutoGenQuery)
        //{
        //    OracleCommand cmd = new OracleCommand();
        //    response = new AppResponse(ResponseStatus.SUCCESS);

        //    try
        //    {
        //        if (MasterQuery.GetStringValue() == "" || ChildQuery.GetStringValue() == "")
        //        {
        //            response.Message = "Missing Query to execute";
        //            response.Status = ResponseStatus.MISSING_DATA;

        //            return response;
        //        }

        //        if (MasterData.HasRecords() == false || ChildData.HasRecords() == false)
        //        {
        //            response.Message = "Missing Data to execute";
        //            response.Status = ResponseStatus.MISSING_DATA;

        //            return response;
        //        }

        //        if (OpenConnection().Status == ResponseStatus.SUCCESS)
        //        {
        //            //Initiate Transaction
        //            //Execute Master Query
        //            //If success, 
        //            //  for each record in child table,
        //            //  {    
        //            //      execute child query
        //            //      if executing child query failed
        //            //      then Rollback and return failure message
        //            //  }
        //            //  CommitTransaction and return success message
        //            //else Rollback Transaction and return failure
        //            InitiateTransaction();

        //            if (ExecuteQuery(MasterQuery, MasterData))
        //            {
        //                if (!ExecuteQuery(ChildQuery, ChildData))
        //                {
        //                    RollbackTransaction();
        //                    response.Status = ResponseStatus.FAILURE;
        //                }
        //            }
        //            else
        //            {
        //                RollbackTransaction();
        //                response.Status = ResponseStatus.FAILURE;
        //            }

        //            if (UpdateAutoGenQuery.GetStringValue() != "")
        //            {
        //                if (ExecuteNonQuery(UpdateAutoGenQuery) != 1)
        //                {
        //                    RollbackTransaction();
        //                    response.Message = "Failed to Update Auto generation No";
        //                    response.Status = ResponseStatus.FAILURE;
        //                }
        //            }

        //            if (response.Status == ResponseStatus.SUCCESS)
        //                CommitTransaction();
        //            else
        //                RollbackTransaction();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        response.Status = ResponseStatus.EXCEPTION;
        //        response.Message = ex.Message;

        //        RollbackTransaction();
        //    }

        //    return response;
        //}

        //public AppResponse Insert_Data(string MasterQuery, DataTable MasterData, string ChildTableName, DataTable ChildData)
        //{
        //    SqlCommand cmd = new SqlCommand();
        //    response = new AppResponse();

        //    try
        //    {
        //        if (MasterQuery.GetStringValue() == "" || ChildTableName.GetStringValue() == "")
        //        {
        //            response.Message = "Missing Query to execute";
        //            response.Status = ResponseStatus.MISSING_DATA;

        //            return response;
        //        }

        //        if (MasterData.HasRecords() == false || ChildData.HasRecords() == false)
        //        {
        //            response.Message = "Missing Data to execute";
        //            response.Status = ResponseStatus.MISSING_DATA;

        //            return response;
        //        }

        //        if (OpenConnection().Status == ResponseStatus.SUCCESS)
        //        {
        //            //Initiate Transaction
        //            //Execute Master Query
        //            //If success, 
        //            //  if bulk inserting the child table is failed then
        //            //  {    
        //            //      then Rollback and return failure message
        //            //  }
        //            //  CommitTransaction and return success message
        //            //else Rollback Transaction and return failure
        //            InitiateTransaction();

        //            if (ExecuteQuery(MasterQuery, MasterData))
        //            {
        //                if (!BulkInsert(ChildTableName, ChildData))
        //                {
        //                    RollbackTransaction();
        //                    response.Status = ResponseStatus.FAILURE;
        //                    goto lblEnd;
        //                }
        //            }
        //            else
        //            {
        //                RollbackTransaction();
        //                response.Status = ResponseStatus.FAILURE;
        //                goto lblEnd;
        //            }

        //            CommitTransaction();
        //        }

        //        lblEnd:
        //        return response;
        //    }
        //    catch (Exception ex)
        //    {
        //        response.Status = ResponseStatus.EXCEPTION;
        //        response.Message = ex.Message;

        //        RollbackTransaction();
        //    }

        //    return response;
        //}

        public AppResponse InsertData(string MasterQuery, DataTable MasterData, string ChildQuery, DataTable ChildData, string UpdateAutoGenQuery)
        {
            SqlCommand cmd = new SqlCommand();
            response = new AppResponse(ResponseStatus.SUCCESS);

            try
            {
                if (MasterQuery.GetStringValue() == "" || ChildQuery.GetStringValue() == "")
                {
                    response.Message = "Missing Query to execute";
                    response.Status = ResponseStatus.MISSING_DATA;

                    return response;
                }

                if (MasterData.HasRecords() == false || ChildData.HasRecords() == false)
                {
                    response.Message = "Missing Data to execute";
                    response.Status = ResponseStatus.MISSING_DATA;

                    return response;
                }

                if (OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    //Initiate Transaction
                    //Execute Master Query
                    //If success, 
                    //  for each record in child table,
                    //  {    
                    //      execute child query
                    //      if executing child query failed
                    //      then Rollback and return failure message
                    //  }
                    //  CommitTransaction and return success message
                    //else Rollback Transaction and return failure
                    InitiateTransaction();

                    if (ExecuteQuery(MasterQuery, MasterData))
                    {
                        if (!ExecuteQuery(ChildQuery, ChildData))
                        {
                            RollbackTransaction();
                            response.Status = ResponseStatus.FAILURE;
                        }
                    }
                    else
                    {
                        RollbackTransaction();
                        response.Status = ResponseStatus.FAILURE;
                    }

                    if (UpdateAutoGenQuery.GetStringValue() != "")
                    {
                        if (ExecuteNonQuery(UpdateAutoGenQuery) != 1)
                        {
                            RollbackTransaction();
                            response.Message = "Failed to Update Auto generation No";
                            response.Status = ResponseStatus.FAILURE;
                        }
                    }

                    if (response.Status == ResponseStatus.SUCCESS)
                        CommitTransaction();
                    else
                        RollbackTransaction();
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;

                RollbackTransaction();
            }

            return response;
        }

        public AppResponse Insert_Data(string MasterQuery, DataTable MasterData, string ChildTableName, DataTable ChildData)
        {
            SqlCommand cmd = new SqlCommand();
            response = new AppResponse();

            try
            {
                if (MasterQuery.GetStringValue() == "" || ChildTableName.GetStringValue() == "")
                {
                    response.Message = "Missing Query to execute";
                    response.Status = ResponseStatus.MISSING_DATA;

                    return response;
                }

                if (MasterData.HasRecords() == false || ChildData.HasRecords() == false)
                {
                    response.Message = "Missing Data to execute";
                    response.Status = ResponseStatus.MISSING_DATA;

                    return response;
                }

                if (OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    //Initiate Transaction
                    //Execute Master Query
                    //If success, 
                    //  if bulk inserting the child table is failed then
                    //  {    
                    //      then Rollback and return failure message
                    //  }
                    //  CommitTransaction and return success message
                    //else Rollback Transaction and return failure
                    InitiateTransaction();

                    if (ExecuteQuery(MasterQuery, MasterData))
                    {
                        if (!BulkInsert(ChildTableName, ChildData))
                        {
                            RollbackTransaction();
                            response.Status = ResponseStatus.FAILURE;
                            goto lblEnd;
                        }
                    }
                    else
                    {
                        RollbackTransaction();
                        response.Status = ResponseStatus.FAILURE;
                        goto lblEnd;
                    }

                    CommitTransaction();
                }

                lblEnd:
                return response;
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;

                RollbackTransaction();
            }

            return response;
        }

        public AppResponse ExecuteQueries(List<Query> queries)
        {
            SqlCommand cmd = new SqlCommand();
            response = new AppResponse(ResponseStatus.SUCCESS);

            try
            {
                if (OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    //Initiate Transaction                    
                    //  for each query,
                    //  {    
                    //      if executing child query failed
                    //      then Rollback and return failure message
                    //  }
                    //  CommitTransaction and return success message

                    InitiateTransaction();

                    foreach (Query Query in queries)
                    {
                        if (Query.type == QueryType.Parameterized)
                        {
                            if (!ExecuteQuery(Query.QueryToRun, Query.DataForQuery))
                            {
                                RollbackTransaction();
                                response.Status = ResponseStatus.FAILURE;
                                break;
                            }
                        }
                        else
                        {
                            if (ExecuteNonQuery(Query.QueryToRun) == 0)
                            {
                                RollbackTransaction();
                                response.Status = ResponseStatus.FAILURE;
                                break;
                            }
                        }
                    }

                    if (response.Status == ResponseStatus.SUCCESS)
                        CommitTransaction();
                    else
                        RollbackTransaction();
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.EXCEPTION;
                response.Message = ex.Message;

                RollbackTransaction();
            }

            return response;
        }

        public int ExecuteNonQuery(string sqlQuery)
        {
            try
            {
                if (OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, Con))
                    {
                        return cmd.ExecuteNonQuery();
                    }
                }

                CloseConnection();
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return 0;
        }

        public bool ExecuteQuery(string sqlQuery, DataTable queryData)
        {
            bool blnResult = false;

            try
            {
                // Get Each Row  
                foreach (DataRow row in queryData.Rows)
                {
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, Con))
                    {
                        // Get Each Columns, add to Parameters
                        foreach (DataColumn column in queryData.Columns)
                        {
                            //Create and Add Values on Parameters
                            //Parameter = New OracleParameter(column.ToString, OracleDbType.NVarchar2, 50, ParameterDirection.InputOutput, True, 50, 50, column.ToString, DataRowVersion.Default, row.item(column.ToString).ToString)
                            //cmd.Parameters.Add(Parameter)

                            //If Query.ToUpper().Contains("<>:" & column.ToString().ToUpper()) Then
                            //    Query.Replace("<>:" & column.ToString().ToUpper(), " IS NOT NULL ")
                            //ElseIf Query.ToUpper().Contains("<> :" & column.ToString().ToUpper()) Then
                            //    Query.Replace("<> :" & column.ToString().ToUpper(), " IS NOT NULL ")
                            //End If

                            if (sqlQuery.ToUpper().Contains(":" + column.ToString().ToUpper()))
                            {
                                if (object.ReferenceEquals(row[column], DBNull.Value))
                                {
                                    cmd.Parameters.Add(column.ToString(), DBNull.Value);
                                }
                                else
                                {
                                    cmd.Parameters.Add(column.ToString(), row[column]);
                                }
                            }
                        }
                        // Execute Query on Each Row
                        cmd.ExecuteNonQuery();
                    }
                }

                blnResult = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return blnResult;
        }

        public bool ExecuteNonQuery(string sqlQuery, DataTable queryData)
        {
            bool blnResult = false;

            try
            {
                if (OpenConnection().Status == ResponseStatus.SUCCESS)
                {
                    InitiateTransaction();

                    blnResult = ExecuteQuery(sqlQuery, queryData);

                    if (blnResult)
                        CommitTransaction();
                    else
                        RollbackTransaction();
                }

                blnResult = true;
            }
            catch (Exception ex)
            {
                RollbackTransaction();
                throw ex;
            }

            return blnResult;
        }

        public void InitiateTransaction()
        {
            //If there is an open Transaction, return the same object
            if (IsOpenTransaction)
            {
                return;
            }

            if (Con.State != ConnectionState.Open)
            {
                OpenConnection();
            }

            if (Con.State == ConnectionState.Open)
            {
                IsOpenTransaction = true;
                Trans = Con.BeginTransaction();
            }
            else
            {
                return;
            }
        }

        public bool CommitTransaction()
        {
            if (Trans != null)
            {
                Trans.Commit();
                CloseConnection();

                IsOpenTransaction = false;

                return true;
            }
            else
            {
                return false;
            }
        }

        public bool RollbackTransaction()
        {
            if (Trans != null)
            {
                Trans.Rollback();

                IsOpenTransaction = false;

                CloseConnection();

                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public class ParameterizedQuery : IQuery
    {
        public string QueryToRun { get; set; }
        public DataTable DataForQuery;
    }

    public class NormalQuery : IQuery
    {
        public string QueryToRun { get; set; }
    }

    public interface IQuery
    {
        string QueryToRun { get; set; }
    }

    public class Query
    {
        public string QueryToRun;
        public DataTable DataForQuery;
        internal QueryType type;

        public Query(QueryType _type)
        {
            type = _type;
        }

        public Query(QueryType _type, string _query)
        {
            QueryToRun = _query;
            type = _type;
        }

        public Query(QueryType _type, string _query, DataTable _data)
        {
            DataForQuery = _data;
            QueryToRun = _query;
            type = _type;
        }
    }

    public enum QueryType
    {
        Parameterized,
        Normal
    }

}
